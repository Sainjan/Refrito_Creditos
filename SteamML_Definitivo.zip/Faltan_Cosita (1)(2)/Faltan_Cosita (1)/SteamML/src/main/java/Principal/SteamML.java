package Principal;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
 
import Servicio.UsuarioServicio;
import BDD.ConexionBDD;
import BDD.Logs;
import Servicio.SolicitudServicio;
 
import Interfaz.*;
 
import javax.swing.SwingUtilities;
import javax.swing.JOptionPane;
 
 
public class SteamML {
   
    static UsuarioServicio us;
    static Logs log;
    static ConexionBDD con_bd;
    static SolicitudServicio sol;
    
    // Única instancia compartida del servicio de usuario (la que tiene la sesión iniciada).
    // Login, Registro y el resto de las pantallas deben usar ESTA, no crear otra con "new UsuarioServicio()".
    public static UsuarioServicio obtenerUsuarioServicio() {
        return us;
    }
    
    public static void main(String[] args) {
 
        // Orden de arranque: conexión, Logs, UsuarioServicio y SolicitudServicio.
        // Si algo falla no tiene sentido abrir la interfaz: todo explotaría después con NullPointerException.
        try
        {
            SteamML.con_bd = new ConexionBDD();
            SteamML.log = new Logs();
            SteamML.us = new UsuarioServicio();
            SteamML.sol = new SolicitudServicio();
        } catch (Exception e)
        {
            System.err.println(e);
            String detalle = (e.getMessage() != null) ? e.getMessage() : e.toString();
            JOptionPane.showMessageDialog(null, "No se pudo iniciar el sistema:\n" + detalle, "Error de inicio", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
            return;
        }
 
        //INICIO DE PROGRAMA
 
        abrir_InterfazInicio();
            
    }
    
    public static void abrir_InterfazInicio()
    {
        SwingUtilities.invokeLater(new Runnable() {
 
        @Override
        public void run() {
            InterfazInicio ini = new InterfazInicio();
            ini.setVisible(true);
            }
        });
    }
 
    // Versión cuando se abre desde el inicio o el login (usa el servicio compartido)
    public static void abrir_InterfazRegistro(int llamador) {
        abrir_InterfazRegistro(llamador, SteamML.us);
    }

    // Versión cuando se abre desde el panel de administración (con servicio)
    public static void abrir_InterfazRegistro(int llamador, UsuarioServicio usuarioServicio) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                InterfazRegistro inre = new InterfazRegistro(llamador, usuarioServicio);
                inre.setVisible(true);
            }
        });
    }
 
    public static void abrir_InterfazInicioSesion() {
 
        SwingUtilities.invokeLater(new Runnable() {
 
            @Override
            public void run() {
                InterfazInicioSesion inins = new InterfazInicioSesion();
                inins.setVisible(true);
            }
 
        });
    }
 
 
    public static void abrir_InterfazAdmin(UsuarioServicio usuarioServicio) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                InterfazAdmin inad = new InterfazAdmin(usuarioServicio);
                inad.setVisible(true);
            }
        });
    }
 
    public static void abrir_InterfazModificarUsuario(UsuarioServicio usuarioServicio, boolean origen) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                InterfazModificarUsuario interfazMod = new InterfazModificarUsuario(usuarioServicio, origen);
                interfazMod.setVisible(true);
            }
        });
    }
     
    public static void abrir_EliminarUser(UsuarioServicio usuarioServicio, boolean origen) {
        SwingUtilities.invokeLater(new Runnable() 
        {
            @Override
            public void run() {
                EliminarUser elus = new EliminarUser(usuarioServicio, origen);
                elus.setVisible(true);
            }
        });
    }
    
    public static void abrir_InterfazInfoSolicitud(Integer id, UsuarioServicio usuarioServicio) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    InterfazInfoSolicitud ininfso = new InterfazInfoSolicitud(id, usuarioServicio);
                    ininfso.setVisible(true);
                } catch (IllegalArgumentException ilae) {
                    JOptionPane.showMessageDialog(null, ilae.getMessage());
                }
            }
        });
    }
 
    public static void abrir_InterfazSolicitudesUsuario(UsuarioServicio usuarioServicio) {
        SwingUtilities.invokeLater(() -> {
            InterfazSolicitudesUsuario insous = new InterfazSolicitudesUsuario(usuarioServicio);
            insous.setVisible(true);
        });
    }
 
    // Recibe el servicio de quien tiene la sesión abierta (antes se pasaba SteamML.us y, si no era
    // la misma instancia que hizo el login, la pantalla decía "No hay una sesión activa").
    public static void abrir_InterfazVerificaContrasena(UsuarioServicio usuarioServicio, int llamador, int direccionador) {
        SwingUtilities.invokeLater(() -> {
            InterfazVerificaContrasena invc = new InterfazVerificaContrasena(usuarioServicio, llamador, direccionador);
            invc.setVisible(true);
        });
    }
}

