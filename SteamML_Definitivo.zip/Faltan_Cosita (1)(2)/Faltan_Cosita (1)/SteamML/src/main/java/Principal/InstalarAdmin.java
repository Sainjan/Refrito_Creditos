package Principal;

import BDD.UsuarioBDD;

public class InstalarAdmin {
    public static void main(String[] args) throws Exception {
        new UsuarioBDD().llenaBase();   // crea el admin si todavía no existe
        System.out.println(UsuarioBDD.definirClaveAdministrador("TuClave"));
    }
}