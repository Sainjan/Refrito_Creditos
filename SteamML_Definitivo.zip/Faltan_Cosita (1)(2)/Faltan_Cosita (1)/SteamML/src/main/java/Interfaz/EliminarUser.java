/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to edit this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interfaz;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import Principal.SteamML;
import Servicio.UsuarioServicio;

public class EliminarUser extends InterfazPrincipal implements ActionListener {
    JButton btn_si, btn_no;
    JLabel lbl_mensaje;

    boolean validador_pasaje = true;
    private UsuarioServicio usuarioServicio; // Referencia al servicio del usuario activo

    public EliminarUser(UsuarioServicio servicio, boolean valor) {
        // Llamamos al constructor de InterfazPrincipal (Título, ancho, alto)
        super("Confirmar acción", 500, 300);
        this.usuarioServicio = servicio;

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent wev)
            {
                if(valor && validador_pasaje)
                {
                    SteamML.abrir_InterfazAdmin(usuarioServicio);
                } else
                {
                    // Cuenta eliminada: no puede quedar ninguna sesión abierta al volver al Inicio.
                    usuarioServicio.cerrar_sesion();
                    SteamML.abrir_InterfazInicio();
                }
            }
        });

        // Mensaje de confirmación
        lbl_mensaje = new JLabel("¿Estás seguro de que deseas eliminar este usuario?", SwingConstants.CENTER);
        lbl_mensaje.setBounds(0, 50, 500, 30);
        add(lbl_mensaje);

        // Configuración botón SI
        btn_si = new JButton("Si");
        btn_si.setBounds(140, 150, 100, 25);
        btn_si.setForeground(Color.WHITE);
        btn_si.setBackground(new Color(0, 100, 60));
        btn_si.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent me)
            {
                btn_si.setBackground(new Color(25, 25, 112));
                btn_si.setForeground(Color.WHITE);
            }

            @Override
            public void mouseExited(MouseEvent mev)
            {
                btn_si.setBackground(new Color(0, 100, 60));
                btn_si.setForeground(Color.WHITE);
            }
        });
        btn_si.addActionListener(this);
        add(btn_si);

        // Configuración botón NO
        btn_no = new JButton("No");
        btn_no.setBounds(260, 150, 100, 25);
        btn_no.setForeground(Color.WHITE);
        btn_no.setBackground(new Color(0, 100, 60));
        btn_no.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent me)
            {
                btn_no.setBackground(new Color(25, 25, 112));
                btn_no.setForeground(Color.WHITE);
            }

            @Override
            public void mouseExited(MouseEvent mev)
            {
                btn_no.setBackground(new Color(0, 100, 60));
                btn_no.setForeground(Color.WHITE);
            }
        });
        btn_no.addActionListener(this);
        add(btn_no);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btn_si) {
            try
            {
                // Llamamos al método de eliminación a través de la instancia de UsuarioServicio
                String res_elim = this.usuarioServicio.eliminarUsuario();

                JOptionPane.showMessageDialog(this, res_elim);

                // Si se eliminó, el servicio deja de tener usuario cargado. Se pregunta eso en vez de
                // comparar el texto del mensaje, que se rompe si alguien cambia una letra.
                if (this.usuarioServicio.extractor() == null) {
                    validador_pasaje = false; // Evita abrir la interfaz anterior si la cuenta fue borrada
                }

                this.dispose();
            } 
            catch (SQLException sqle)
            {
                JOptionPane.showMessageDialog(this, "Error de base de datos: " + sqle.getMessage());
            }
        } else if (e.getSource() == btn_no) {
            this.dispose(); // Cierra la ventana sin hacer nada
        }
    }
}