package Interfaz;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JOptionPane;

import Modelo.Usuario;
import Principal.SteamML;
import Servicio.UsuarioServicio;

// Pantalla principal tras iniciar sesión, para TODOS los roles: los botones se muestran según el ID del usuario.
public class InterfazAdmin extends InterfazPrincipal implements ActionListener {
    
    JButton btnNeuronal, btnCrearUser, btn_elimina, btnListar, btn_modifica;
    boolean validador_cierre = true;
    private UsuarioServicio usuarioServicio;

    public InterfazAdmin(UsuarioServicio usuarioServicio) {
        super("Interfaz administrador", 700, 450);
        this.usuarioServicio = usuarioServicio;

        Usuario actual = usuarioServicio.extractor(); //null si no hay sesión (no lanza excepción como obtenerIDUsuario)
        boolean esAdmin = (actual != null) && (actual.obtIdUsuario() == 1);

        if(!esAdmin)
        {
            setTitle("Panel de usuario");
        }
        
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent wev)
            {
                if(validador_cierre)
                {
                    // Cerrar la ventana con la X termina la sesión; si no, quedaba abierta al volver al Inicio.
                    usuarioServicio.cerrar_sesion();
                    SteamML.abrir_InterfazInicio();
                }
            }
        });

        int y = 110; //Los botones se acomodan hacia abajo sin dejar huecos cuando alguno no se muestra.

        if(esAdmin)
        {
            btnNeuronal = crearBoton("Abrir solicitudes", y);
            add(btnNeuronal);
            y += 60;
        }

        btnListar = crearBoton("Listado De Solicitudes", y);
        add(btnListar);
        y += 60;

        if(esAdmin) //Solo el administrador principal (ID 1) crea usuarios.
        {
            btnCrearUser = crearBoton("Crear nuevo usuario", y);
            add(btnCrearUser);
            y += 60;
        } else //El administrador principal no puede modificar ni eliminar su cuenta.
        {
            btn_modifica = crearBoton("Modificar cuenta", y);
            add(btn_modifica);
            y += 60;

            btn_elimina = crearBoton("Eliminar Usuario", y);
            add(btn_elimina);
        }
    }

    private JButton crearBoton(String texto, int y)
    {
        final JButton boton = new JButton(texto);
        boton.setBounds(225, y, 250, 40);
        boton.setForeground(Color.WHITE);
        boton.setBackground(new Color(0, 100, 60));
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent me)
            {
                boton.setBackground(new Color(25, 25, 112));
                boton.setForeground(Color.WHITE);
            }

            @Override
            public void mouseExited(MouseEvent mev)
            {
                boton.setBackground(new Color(0, 100, 60));
                boton.setForeground(Color.WHITE);
            }
        });
        boton.addActionListener(this);
        return boton;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnNeuronal)
        {
            // PENDIENTE: falta la pantalla para gestionar (aprobar/rechazar) una solicitud.
            JOptionPane.showMessageDialog(this, "Esta función todavía no está disponible.");

        } else if (e.getSource() == btnListar)
        {
            SteamML.abrir_InterfazSolicitudesUsuario(usuarioServicio);
            validador_cierre = false;
            this.dispose();

        } else if (e.getSource() == btnCrearUser)
        {
            // Se pasa el servicio: con null el Registro fallaba al abrirse.
            SteamML.abrir_InterfazRegistro(2, usuarioServicio);
            validador_cierre = false;
            this.dispose();

        } else if (e.getSource() == btn_elimina)
        {
            SteamML.abrir_InterfazVerificaContrasena(usuarioServicio, 1, 1);
            validador_cierre = false;
            this.dispose();

        } else if (e.getSource() == btn_modifica)
        {
            SteamML.abrir_InterfazVerificaContrasena(usuarioServicio, 1, 0);
            validador_cierre = false;
            this.dispose();
        }
    }
}