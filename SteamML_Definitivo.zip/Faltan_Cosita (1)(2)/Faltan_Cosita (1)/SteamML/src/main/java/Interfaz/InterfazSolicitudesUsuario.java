/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;

import Modelo.Solicitud;
import Principal.SteamML;
import Servicio.SolicitudServicio;
import Servicio.UsuarioServicio;

/**
 *
 * @author fran
 */
public class InterfazSolicitudesUsuario extends InterfazPrincipal implements ActionListener {
    
    boolean validador_cierre = true;
    JComboBox<String> cbBuscar, cbEstado;
    JFormattedTextField txtFecha;
    JButton btnFiltrar, btnNoFiltrar;
    DefaultTableModel modelo;
    JTable tabla;
    private UsuarioServicio usuarioServicio;

    public InterfazSolicitudesUsuario(UsuarioServicio usuarioServicio) {
        // Hereda de InterfazPrincipal pasando título, ancho y alto
        super("Listado de Solicitudes de Usuario", 800, 500);
        this.usuarioServicio = usuarioServicio;

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent wev) {
                if(validador_cierre) {
                    SteamML.abrir_InterfazAdmin(usuarioServicio);
                }
            }
        });

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout()); 
        
        // Panel superior para los controles de filtrado
        JPanel panelSuperior = new JPanel();
        panelSuperior.setLayout(null);
        panelSuperior.setPreferredSize(new java.awt.Dimension(800, 80));

        JLabel lblBuscar = new JLabel("Buscar:");
        lblBuscar.setBounds(20, 25, 50, 25);
        panelSuperior.add(lblBuscar);

        cbBuscar = new JComboBox<>(new String[]{"Antes de:", "Después de:"});
        cbBuscar.setBounds(70, 25, 100, 25);
        panelSuperior.add(cbBuscar);

        JLabel lblFecha = new JLabel("Fecha:");
        lblFecha.setBounds(185, 25, 45, 25);
        panelSuperior.add(lblFecha);

        JLabel lblEstado = new JLabel("Estado:");
        lblEstado.setBounds(355, 25, 50, 25);
        panelSuperior.add(lblEstado);

        cbEstado = new JComboBox<>(new String[]{"Aprobado", "Rechazado", "Pendiente"});
        cbEstado.setBounds(410, 25, 110, 25);
        panelSuperior.add(cbEstado);

        btnNoFiltrar = crearBoton("No Filtrar", 650, 15);
        panelSuperior.add(btnNoFiltrar);

        btnFiltrar = crearBoton("Filtrar", 650, 45);
        panelSuperior.add(btnFiltrar);

        try
        {
            MaskFormatter mascara_fecha = new MaskFormatter("##-##-####");
            mascara_fecha.setPlaceholderCharacter('_');

            txtFecha = new JFormattedTextField(mascara_fecha);
            txtFecha.setColumns(10);
            txtFecha.setBounds(230, 25, 110, 25);
            panelSuperior.add(txtFecha);
        } catch (ParseException pe)
        {
            JOptionPane.showMessageDialog(this, pe.getMessage());
        }

        add(panelSuperior, BorderLayout.NORTH);
        
        // Configuración de la tabla: 4 columnas y cada fila carga exactamente esos 4 valores.
        String[] columnas = {"Id", "Fecha", "Monto Máximo", "Estado"};
        modelo = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false; //Es un listado: las celdas no se editan.
            }
        };
        tabla = new JTable(modelo);

        add(new JScrollPane(tabla), BorderLayout.CENTER);

        // Carga inicial: todas las solicitudes del usuario en sesión.
        cargarTabla(null, LocalDate.now().plusDays(1).toString(), false);
    }

    private JButton crearBoton(String texto, int x, int y)
    {
        final JButton boton = new JButton(texto);
        boton.setBounds(x, y, 110, 25);
        boton.setForeground(Color.WHITE);
        boton.setBackground(new Color(0,100,60));
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent moen)
            {
                boton.setBackground(new Color(25,25,112));
                boton.setForeground(Color.WHITE.darker());
            }

            @Override
            public void mouseExited(MouseEvent moex)
            {
                boton.setBackground(new Color(0,100,60));
                boton.setForeground(Color.WHITE);
            }
        });
        boton.addActionListener(this);
        return boton;
    }

    private int idActual()
    {
        return (this.usuarioServicio != null && this.usuarioServicio.extractor() != null) ? this.usuarioServicio.obtenerIDUsuario() : 0;
    }

    // La máscara es dd-MM-yyyy pero el servicio espera yyyy-MM-dd (ISO): se convierte acá.
    // Si la fecha está incompleta ("__-__-____") se usa "mañana", que equivale a no limitar por fecha.
    private String fechaParaBuscar() throws DateTimeParseException
    {
        String txt = (txtFecha != null) ? txtFecha.getText() : null;
        if((txt == null) || txt.contains("_") || txt.isBlank())
        {
            return LocalDate.now().plusDays(1).toString();
        }
        // STRICT: rechaza fechas inexistentes como 31-02-2026 en vez de "corregirlas" en silencio.
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd-MM-uuuu").withResolverStyle(ResolverStyle.STRICT);
        return LocalDate.parse(txt, formato).toString();
    }

    private void cargarTabla(String estado, String fecha, boolean menMas)
    {
        try
        {
            List<Solicitud> registro = SolicitudServicio.mostrar_creditos(estado, fecha, idActual(), menMas);

            modelo.setRowCount(0); // Limpia la tabla para evitar duplicados al filtrar

            for(Solicitud fila : registro)
            {
                modelo.addRow(new Object[] {fila.obtIdSolicitud(), fila.obtFecha(), SolicitudServicio.calcular_monto_maximo(fila), fila.obtEstado()});
            }
        } catch (IllegalArgumentException ilae)
        {
            modelo.setRowCount(0);
            JOptionPane.showMessageDialog(this, ilae.getMessage());
        } catch (Exception ex)
        {
            JOptionPane.showMessageDialog(this, (ex.getMessage() != null) ? ex.getMessage() : ex.toString());
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        if (e.getSource() == btnFiltrar) {
            
            boolean elec_men_mas = (cbBuscar.getSelectedIndex() != 0); //"elec" refiere a electo o elegido 
            String elec_estado = cbEstado.getSelectedItem().toString();

            try
            {
                cargarTabla(elec_estado, fechaParaBuscar(), elec_men_mas);
            } catch (DateTimeParseException dtpe)
            {
                JOptionPane.showMessageDialog(this, "La fecha ingresada no es válida. Use el formato día-mes-año (dd-mm-aaaa).");
            }
            
        } else if (e.getSource() == btnNoFiltrar)
        {
            cargarTabla(null, LocalDate.now().plusDays(1).toString(), false);
        }
    }
}