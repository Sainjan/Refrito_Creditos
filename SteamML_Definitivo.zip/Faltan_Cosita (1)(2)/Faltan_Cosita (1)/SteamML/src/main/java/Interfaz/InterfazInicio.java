package Interfaz;

//IMPORTS DE INTERFAZ
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;

import Principal.SteamML;

public class InterfazInicio extends InterfazPrincipal implements ActionListener {
    JLabel lb_bienvenida, miLabel;
    JButton bt_Registrar, bt_user, bt_salir;

    public InterfazInicio(){

        super("Menú principal", 700, 450);

        setDefaultCloseOperation(InterfazInicio.EXIT_ON_CLOSE);
        
        getContentPane().setBackground(Color.WHITE);
            
        lb_bienvenida = new JLabel("¡HOLA! ¡BIENVENIDO AL REFRITO DE CRÉDITOS!");
        lb_bienvenida.setBounds(150,50,400,40);
        lb_bienvenida.setForeground(new Color(25, 25, 112));

        bt_salir = new JButton("Salir");
        bt_salir.setBounds(400, 230, 80, 30);
        bt_salir.setBackground(new Color(0, 100, 60));
        bt_salir.setForeground(Color.WHITE);
        bt_salir.addActionListener(this);
        
        bt_user = new JButton("Inicio sesion");
        bt_user.setBounds(175,100,150,50);
        bt_user.setBackground(new Color(0, 100, 60));
        bt_user.setForeground(Color.WHITE);
        
        bt_user.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent me)
            {
                bt_user.setBackground(new Color(25, 25, 112));
                bt_user.setForeground(Color.WHITE);
            }

            @Override
            public void mouseExited(MouseEvent mev)
            {
                bt_user.setBackground(new Color(0, 100, 60));
                bt_user.setForeground(Color.WHITE);}
        });
        bt_user.addActionListener(this);
        
        bt_Registrar = new JButton ("Registrarse");
        bt_Registrar.setBounds(175,165,150,50);
        bt_Registrar.setBorder(BorderFactory.createRaisedBevelBorder());
        bt_Registrar.setBackground(new Color(0, 100, 60));
        bt_Registrar.setForeground(Color.WHITE);
        
        bt_Registrar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent me)
            {
                bt_Registrar.setBackground(new Color(25, 25, 112));
                bt_Registrar.setForeground(Color.WHITE);
            }

            @Override
            public void mouseExited(MouseEvent mev)
            {
                bt_Registrar.setBackground(new Color(0, 100, 60));
                bt_Registrar.setForeground(Color.WHITE);}
        });
        bt_Registrar.addActionListener(this);

        // Logo: si el archivo no existe en esta máquina simplemente no se muestra (antes quedaba un icono roto).
        miLabel = new JLabel();
        File archivoLogo = new File("/home/fran/Escritorio/Captura desde 2026-06-08 13-39-41.png"); //Intentar volverlo XML
        if (archivoLogo.exists())
        {
            java.awt.Image img = new ImageIcon(archivoLogo.getPath()).getImage();
            miLabel.setIcon(new ImageIcon(img.getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH)));
        }
        miLabel.setBounds(10, 10, 50, 50); // Arriba a la izquierda (10,10)

        // Agregar los elementos a la ventana
        add(lb_bienvenida);
        add(bt_user);
        add(bt_Registrar);
        add(miLabel);
        add(bt_salir);

        // Pantalla de carga: es modal, por eso el Timer la cierra solo a los 1,5 s
        // (si no, quedaba bloqueando todo cada vez que se volvía al inicio).
        javax.swing.SwingUtilities.invokeLater(() -> {
            InterfazCarga carga = new InterfazCarga(this);
            javax.swing.Timer cierre = new javax.swing.Timer(1500, ev -> carga.dispose());
            cierre.setRepeats(false);
            cierre.start();
            carga.setVisible(true);
        });

    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource() == bt_Registrar){
            SteamML.abrir_InterfazRegistro(1);
            this.dispose();
        } else if (e.getSource() == bt_user){
            SteamML.abrir_InterfazInicioSesion();
            this.dispose();
        }else if (e.getSource() == bt_salir){
            System.exit(0);
        }
    }
}