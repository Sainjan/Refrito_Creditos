/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interfaz;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Principal.SteamML;
import Servicio.UsuarioServicio;

/**
 *
 * @author fran
 */
public class InterfazModificarUsuario extends InterfazPrincipal implements ActionListener {
    JLabel nombre_user, contrasena_user;
    JTextField text_user;
    JPasswordField con_user; 
    JButton btn_Guardar;
    boolean validador_cierre = true;
    private UsuarioServicio usuarioServicio;
    private boolean origenVentana; // true para admin, false para cliente

    public InterfazModificarUsuario(UsuarioServicio usuarioServicio, boolean origen) {
        // Hereda de InterfazPrincipal pasando título, ancho y alto
        super("Modificar usuario", 500, 300);

        this.usuarioServicio = usuarioServicio;
        this.origenVentana = origen;

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent wev)
            {
                if(validador_cierre)
                {
                    if (origenVentana) {
                        SteamML.abrir_InterfazAdmin(usuarioServicio);
                    }
                }
            }
        });

        nombre_user = new JLabel("Ingrese el nuevo nombre que desea: ");
        nombre_user.setBounds(50, 40, 400, 25);
        nombre_user.setForeground(new Color(25, 25, 112)); 
        add(nombre_user);
       
        text_user = new JTextField("Pepe");
        text_user.setForeground(Color.LIGHT_GRAY);
        text_user.setBounds(50, 70, 400, 30);
        text_user.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent fe)
            {
                if(text_user.getText().equals("Pepe"))
                {
                    text_user.setText("");
                    text_user.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent fev)
            {
                if(text_user.getText().isEmpty())
                {
                    text_user.setText("Pepe");
                    text_user.setForeground(Color.LIGHT_GRAY);
                }
            }
        });
        add(text_user);
       
        contrasena_user = new JLabel("Ingrese la nueva contraseña que desea");
        contrasena_user.setBounds(50, 120, 400, 25);
        contrasena_user.setForeground(new Color(25, 25, 112)); 
        add(contrasena_user);
       
        con_user = new JPasswordField("contrasena123");
        con_user.setForeground(Color.LIGHT_GRAY);
        con_user.setBounds(50, 150, 400, 30);
        con_user.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent fe)
            {
                String actual = new String(con_user.getPassword());
                if(actual.equals("contrasena123"))
                {
                    con_user.setText("");
                    con_user.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent fev)
            {
                String actual = new String(con_user.getPassword());
                if(actual.isEmpty())
                {
                    con_user.setText("contrasena123");
                    con_user.setForeground(Color.LIGHT_GRAY);
                }
            }
        });
        add(con_user);
        
        btn_Guardar = new JButton("Guardar");
        btn_Guardar.setBounds(200, 220, 100, 30);
        btn_Guardar.setForeground(Color.WHITE);
        btn_Guardar.setBackground(new Color(0, 100, 60));
        
        btn_Guardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent me)
            {
                btn_Guardar.setBackground(new Color(25, 25, 112));
                btn_Guardar.setForeground(Color.WHITE);
            }

            @Override
            public void mouseExited(MouseEvent mev)
            {
                btn_Guardar.setBackground(new Color(0, 100, 60));
                btn_Guardar.setForeground(Color.WHITE);
            }
        });
        btn_Guardar.addActionListener(this);
        add(btn_Guardar);
    }
  
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btn_Guardar) {
            try {
                String nombre_nuevo = text_user.getText();
                // Si el usuario dejó el texto por defecto o vacío, manejamos los nulos adecuadamente para el servicio
                if (nombre_nuevo.equals("Pepe") || nombre_nuevo.isBlank()) {
                    nombre_nuevo = null;
                }

                char[] passChars = con_user.getPassword();
                String contra_nueva = new String(passChars);
                if (contra_nueva.equals("contrasena123") || contra_nueva.isBlank()) {
                    contra_nueva = null;
                }

                // Invocamos el método de modificación a través de la capa de servicios
                String msg = this.usuarioServicio.modificar_usr(nombre_nuevo, contra_nueva);
                JOptionPane.showMessageDialog(this, msg, "Información", JOptionPane.INFORMATION_MESSAGE);
                
                // Lógica de navegación manteniendo la sesión activa
                validador_cierre = false;
                this.dispose();
                
                if (origenVentana) {
                    SteamML.abrir_InterfazAdmin(this.usuarioServicio);
                } 
                
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Ocurrió un error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}