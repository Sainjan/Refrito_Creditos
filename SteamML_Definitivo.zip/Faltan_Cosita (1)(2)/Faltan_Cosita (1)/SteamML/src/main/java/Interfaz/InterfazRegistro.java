/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interfaz;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Modelo.Cargo;
import Principal.SteamML;
import Servicio.UsuarioServicio;

public class InterfazRegistro extends InterfazPrincipal implements ActionListener {
   JLabel  lb_nombre, lb_contrasena;
   JTextField txt_nombre;
   JPasswordField txt_contrasena;
   JButton btn_ingresar; 
   JComboBox<String> asignador_rol;

    boolean validador_cierre = true;
    UsuarioServicio usuarioServ;

    // Desde Inicio o Login: usa el servicio compartido (antes recibía null y fallaba con NullPointerException).
    public InterfazRegistro(int llamador) {
        this(llamador, SteamML.obtenerUsuarioServicio());
    }

    public InterfazRegistro(int pasador, UsuarioServicio userv) {

        super("Registro", 700, 450);//Constructor

        this.usuarioServ = userv;

        addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosed(WindowEvent wev) {

                if((validador_cierre) && (pasador == 1)) 
                {
                    SteamML.abrir_InterfazInicio();
                } else if ((validador_cierre) && (pasador == 0))
                {
                    SteamML.abrir_InterfazInicioSesion();
                } else if((validador_cierre) && (pasador == 2))
                {
                    SteamML.abrir_InterfazAdmin(usuarioServ);
                }

            } 

        });

        lb_nombre = new JLabel("Ingrese su nombre de usuario:");
        lb_nombre.setBounds(50,30,300,20);
        lb_nombre.setForeground(new Color(25, 25, 112));

        txt_nombre = new JTextField();
        txt_nombre.setBounds(245,30,150,20);
        aplicarPlaceholder(txt_nombre, "Pepe");

        lb_contrasena = new JLabel("Ingrese su contraseña:");
        lb_contrasena.setBounds(50,110,300,20);
        lb_contrasena.setForeground(new Color(25, 25, 112));

        txt_contrasena = new JPasswordField();
        txt_contrasena.setBounds(245,110,150,20);
        aplicarPlaceholder(txt_contrasena, "contrasena123");

        JLabel as_rol_lbl = new JLabel("Rol:");
        as_rol_lbl.setBounds(50,150,50,20);
        as_rol_lbl.setForeground(new Color(25,25,112));

        // Solo Persona y Empresa: UsuarioServicio.registrar_usuario no crea Administradores
        // (el ID 1 es el único administrador y ya existe).
        asignador_rol = new JComboBox<>(new String[]{Cargo.PERSONA.obtDescripcion(), Cargo.EMPRESA.obtDescripcion()});
        asignador_rol.setBounds(245,150,150,20);

        btn_ingresar = new JButton("Registrarse");
        btn_ingresar.setBounds(150,210,150,40);
        btn_ingresar.setForeground(Color.WHITE);
        btn_ingresar.setBackground(new Color(0, 100, 60));
        btn_ingresar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent me) {
                btn_ingresar.setBackground(new Color(25, 25, 112));
            }
            @Override
            public void mouseExited(MouseEvent mev) {
                btn_ingresar.setBackground(new Color(0, 100, 60));
            }
        });
        btn_ingresar.addActionListener(this);

        add(lb_nombre);
        add(txt_nombre);
        add(lb_contrasena);
        add(txt_contrasena);
        add(as_rol_lbl);
        add(asignador_rol);
        add(btn_ingresar);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // valorCampo devuelve el texto real ("" si el campo sigue mostrando el ejemplo gris).
        // Antes: getPassword().toString() guardaba algo como "[C@1b6d3586" como contraseña.
        String nom_obt = valorCampo(txt_nombre);
        String con_obt = valorCampo(txt_contrasena);

        Cargo cargo = (asignador_rol.getSelectedIndex() == 1) ? Cargo.EMPRESA : Cargo.PERSONA;

        try {

            String resultado = this.usuarioServ.registrar_usuario(nom_obt, con_obt, cargo);

            JOptionPane.showMessageDialog(this, resultado);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Ocurrió un error: " + ex.getMessage());
        }
    }
}