package Interfaz;

import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPasswordField;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;

public abstract class InterfazPrincipal extends JFrame {

    protected JMenuBar menuBarComun;
    protected JPopupMenu menuContextual;

    public InterfazPrincipal(String titulo, int ancho, int alto) {
        setTitle(titulo);
        setSize(ancho, alto);
        setLocationRelativeTo(null); // Centra la ventana en la pantalla
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        menuBarComun = new JMenuBar();

        // Ejemplo de un menú desplegable superior
        JMenu menuArchivo = new JMenu("Archivo");
        JMenuItem itemSalir = new JMenuItem("Salir");
        itemSalir.addActionListener(e -> System.exit(0)); // Sale de la JVM
        
        menuArchivo.add(itemSalir);
        menuBarComun.add(menuArchivo);

        setJMenuBar(menuBarComun);

        // Configuración del menú contextual
        menuContextual = new JPopupMenu();
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                revisarPopup(e);
            }
            @Override
            public void mouseReleased(MouseEvent e) {
                revisarPopup(e);
            }
            private void revisarPopup(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    menuContextual.show(e.getComponent(), e.getX(), e.getY());
                }
            }
        });
    }

    //=================== PLACEHOLDERS (texto gris de ejemplo en los campos) ===================
    // El "estado" del placeholder es el color del texto: gris claro = se está mostrando el ejemplo.
    // Así no se compara el texto (comparar con "Pepe" o "contrasena123" confundía a un usuario
    // que de verdad escribiera eso) ni se usa getPassword().toString() (que devuelve "[C@1b6d...").

    protected static boolean esPlaceholder(JTextField campo) {
        return Color.LIGHT_GRAY.equals(campo.getForeground());
    }

    private static boolean campoVacio(JTextField campo) {
        if (campo instanceof JPasswordField) {
            return ((JPasswordField) campo).getPassword().length == 0;
        }
        return campo.getText().isEmpty();
    }

    /** Devuelve lo que escribió el usuario ("" si el campo todavía muestra el ejemplo). */
    protected static String valorCampo(JTextField campo) {
        if (esPlaceholder(campo)) {
            return "";
        }
        if (campo instanceof JPasswordField) {
            return new String(((JPasswordField) campo).getPassword());
        }
        return campo.getText().trim();
    }

    protected static void aplicarPlaceholder(final JTextField campo, final String texto) {
        final JPasswordField clave = (campo instanceof JPasswordField) ? (JPasswordField) campo : null;
        final char eco = (clave != null) ? clave.getEchoChar() : 0;

        campo.setText(texto);
        campo.setForeground(Color.LIGHT_GRAY);
        if (clave != null) {
            clave.setEchoChar((char) 0); // El ejemplo se ve como texto, no como puntitos.
        }

        campo.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent fe) {
                if (esPlaceholder(campo)) {
                    campo.setText("");
                    campo.setForeground(Color.BLACK);
                    if (clave != null) {
                        clave.setEchoChar(eco);
                    }
                }
            }

            @Override
            public void focusLost(FocusEvent fe) {
                if (campoVacio(campo)) {
                    campo.setText(texto);
                    campo.setForeground(Color.LIGHT_GRAY);
                    if (clave != null) {
                        clave.setEchoChar((char) 0);
                    }
                }
            }
        });
    }
}