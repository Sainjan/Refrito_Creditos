/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interfaz;

import Servicio.UsuarioServicio;

/**
 * Esta pantalla era una copia exacta de InterfazSolicitudesUsuario (con los mismos errores), así que
 * ahora la reutiliza: muestra el mismo listado y deja seleccionada la solicitud cuyo id recibe.
 * Cuando exista la pantalla de detalle (aprobar/rechazar) se reemplaza el contenido de esta clase.
 *
 * @author fran
 */
public class InterfazInfoSolicitud extends InterfazSolicitudesUsuario {

    public InterfazInfoSolicitud(Integer id, UsuarioServicio usuarioServicio) {
        super(usuarioServicio);
        setTitle("Información de solicitud");

        if(id != null)
        {
            for(int fila = 0; fila < modelo.getRowCount(); fila++)
            {
                if(id.equals(modelo.getValueAt(fila, 0)))
                {
                    tabla.setRowSelectionInterval(fila, fila);
                    break;
                }
            }
        }
    }
}