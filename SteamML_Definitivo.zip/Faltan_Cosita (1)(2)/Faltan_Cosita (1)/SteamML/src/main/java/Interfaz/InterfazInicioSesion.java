/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interfaz;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Principal.SteamML;
import Servicio.UsuarioServicio;

public class InterfazInicioSesion extends InterfazPrincipal implements ActionListener {
    JLabel lb_nombre, miLabel, lb_contrasena;
    JTextField txt_nombre;
    JPasswordField txt_contrasena; 
    JButton btn_ingresar, btn_registrar; 
    boolean validador_cierre = true;

    public InterfazInicioSesion() {
        // Hereda de InterfazPrincipal pasando título, ancho y alto
        super("Inicio sesión", 500, 300);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent wev)
            {
                if(validador_cierre)
                {
                    SteamML.abrir_InterfazInicio();
                }
            }
        });
        
        miLabel = new JLabel();
        File archivoLogo = new File("/home/fran/Escritorio/Captura desde 2026-06-08 13-39-41.png");
        if (archivoLogo.exists())
        {
            java.awt.Image img = new ImageIcon(archivoLogo.getPath()).getImage();
            miLabel.setIcon(new ImageIcon(img.getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH)));
        }
        miLabel.setBounds(450, 0, 50, 50);
    
        lb_nombre = new JLabel("Ingrese su nombre de usuario:");
        lb_nombre.setBounds(50, 50, 300, 40);
        lb_nombre.setForeground(new Color(25, 25, 112)); 
        
        txt_nombre = new JTextField();
        txt_nombre.setBounds(235, 56, 150, 30);
        aplicarPlaceholder(txt_nombre, "Pepe");
        
        lb_contrasena = new JLabel("Ingrese su contraseña: ");
        lb_contrasena.setBounds(50, 100, 300, 40);
        lb_contrasena.setForeground(new Color(25, 25, 112));
        
        txt_contrasena = new JPasswordField();
        txt_contrasena.setBounds(188, 108, 200, 30);
        aplicarPlaceholder(txt_contrasena, "contrasena123");

        btn_ingresar = crearBoton("Ingresar", 175, 160, 150, 45);
        btn_registrar = crearBoton("Registrarse", 175, 215, 150, 30);

        add(miLabel);
        add(lb_nombre);
        add(txt_nombre);
        add(lb_contrasena);
        add(txt_contrasena);
        add(btn_ingresar);
        add(btn_registrar);
    }

    private JButton crearBoton(String texto, int x, int y, int ancho, int alto)
    {
        final JButton boton = new JButton(texto);
        boton.setBounds(x, y, ancho, alto);
        boton.setForeground(Color.WHITE);
        boton.setBackground(new Color(0, 100, 60));
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent me)
            {
                boton.setBackground(new Color(25, 25, 112));
            }

            @Override
            public void mouseExited(MouseEvent mev)
            {
                boton.setBackground(new Color(0, 100, 60));
            }
        });
        boton.addActionListener(this);
        return boton;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == btn_ingresar) {

            String nom_obt = valorCampo(txt_nombre);
            String con_final = valorCampo(txt_contrasena);

            if(nom_obt.isEmpty() || con_final.isEmpty())
            {
                JOptionPane.showMessageDialog(this, "Complete el usuario y la contraseña, por favor.");
                return;
            }

            try {
                // Servicio compartido: es el mismo que van a usar después Admin, VerificaContraseña, etc.
                // (antes se creaba uno nuevo en cada login y se volvía a ejecutar UsuarioBDD.inicializar()).
                UsuarioServicio servicio = SteamML.obtenerUsuarioServicio();
                servicio.cerrar_sesion(); //Por si quedó una sesión anterior abierta.

                int resultadoId = servicio.iniciar_sesion(nom_obt, con_final);

                if(resultadoId != -1) {
                    // Todos los roles entran a la misma pantalla; ella oculta los botones que no corresponden según el ID.
                    validador_cierre = false;
                    SteamML.abrir_InterfazAdmin(servicio);
                    this.dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "El usuario indicado no existe o la contraseña es incorrecta");
                }

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Ocurrió un error: " + ex.getMessage());
            }
            
        } else if(e.getSource() == btn_registrar) {
            // El Login se cierra para que no queden dos ventanas abiertas; al cerrar el Registro vuelve acá.
            validador_cierre = false;
            SteamML.abrir_InterfazRegistro(0);
            this.dispose();
        }
    }
}