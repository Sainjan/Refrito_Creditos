package BDD;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import Modelo.Solicitud;
import Servicio.Logs_Intermedio;

public class SolicitudBDD {

    // ---------- Contrato con los SP (esquema Credito) ----------
    private static final String SP_EXTRACTOR  = "{CALL Credito.Extractor_Solicitud(?)}";               // IN (ID_Solicitud); devuelve 0 filas si no existe
    private static final String SP_BUSCAR     = "{CALL Credito.Buscar_Solicitud(?,?,?,?,?,?)}";       // (gestionar, estado, fecha, criterio CHAR(1), Mensaje_OUT, Exito_OUT)
    private static final String SP_SOLICITAR  = "{CALL Credito.Solicitar_Credito(?,?,?,?)}";          // IN (ID_Cliente, Nombre, Ingreso INT, Gastos DECIMAL(10,2))
    private static final String SP_ASIGNADOR  = "{CALL Credito.Asignador_Estado(?,?,?)}";             // IN (ID_Solicitud, 'Aprobado'|'Rechazado', ID_Usuario[log])

    private ConexionBDD conexionBDD;

    public SolicitudBDD() {
        try {
            this.conexionBDD = new ConexionBDD();
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo inicializar la conexión: " + e.getMessage(), e);
        }
    }

    // ------------------------------------------------------------------
    // Lectura
    // ------------------------------------------------------------------

    /**
     * Mapea una fila con las columnas reales de los SP. No consulta usuarios (evita una query por fila
     * y el error de pasar un idCliente como idUsuario).
     */
    private static Solicitud mapear_fila_solicitud(ResultSet rs) throws SQLException {
        int idSolicitud = rs.getInt("idSolicitud");
        int idCliente = rs.getInt("idCliente");
        // La columna real se llama "ingresoAcutla" (typo en la tabla); "ingresoActual" queda como alternativa si se corrige.
        double ingresos = SPUtil.getDouble(rs, "ingresoActual", "ingresoAcutla");
        double gastos = rs.getDouble("gastoAnual");
        String estado = rs.getString("estadoSolicitud");
        String fecha = rs.getString("fechaSolicitud");
        if (fecha != null && fecha.length() > 10) {
            fecha = fecha.substring(0, 10); // yyyy-MM-dd, por si la columna es DATETIME
        }
        return new Solicitud(idSolicitud, idCliente, ingresos, gastos, estado, fecha);
    }

    /** @return la solicitud, o null si no existe. Lanza IllegalArgumentException si el SP emite una advertencia. */
    public static Solicitud extractor_sol(Integer id_sol) throws SQLException {
        if (id_sol == null) {
            throw new IllegalArgumentException("El ID de solicitud no puede ser nulo.");
        }
        try (CallableStatement cs = ConexionBDD.cn.prepareCall(SP_EXTRACTOR)) {
            cs.setInt(1, id_sol);
            boolean tiene = cs.execute();
            if (!tiene) {
                return null;
            }
            ResultSet rs = cs.getResultSet();
            if (rs == null) {
                return null;
            }
            if (SPUtil.tieneColumna(rs, "ADVERTENCIA")) {
                if (rs.next()) {
                    throw new IllegalArgumentException(rs.getString("ADVERTENCIA"));
                }
                return null;
            }
            return rs.next() ? mapear_fila_solicitud(rs) : null;

        } catch (SQLException e) {
            throw new SQLException("Error al intentar buscar la solicitud con ID " + id_sol + " en extractor_sol(): " + e.getMessage(), e);
        }
    }

    /**
     * @param gestionar     modo gestión (el SP no devuelve result set si no hay resultados).
     * @param criterioFecha '<', '=' o '>'.
     */
    public static ArrayList<Solicitud> buscarSolicitudes(boolean gestionar, String estado, LocalDate fecha, char criterioFecha) throws SQLException {
        if (criterioFecha != '<' && criterioFecha != '=' && criterioFecha != '>') {
            throw new IllegalArgumentException("Criterio de fecha inválido: debe ser '<', '=' o '>'.");
        }
        ArrayList<Solicitud> lista = new ArrayList<>();

        try (CallableStatement cs = ConexionBDD.cn.prepareCall(SP_BUSCAR)) {
            cs.setBoolean(1, gestionar);
            if (estado != null && !estado.isBlank()) { cs.setString(2, estado); } else { cs.setNull(2, java.sql.Types.VARCHAR); }
            if (fecha != null) { cs.setDate(3, java.sql.Date.valueOf(fecha)); } else { cs.setNull(3, java.sql.Types.DATE); }
            cs.setString(4, String.valueOf(criterioFecha));
            cs.registerOutParameter(5, java.sql.Types.VARCHAR);  // Mensaje_OUT
            cs.registerOutParameter(6, java.sql.Types.BOOLEAN);  // Exito_OUT

            // execute() (no executeQuery): sin resultados el SP no devuelve result set.
            boolean tiene = cs.execute();
            while (true) {
                if (tiene) {
                    ResultSet rs = cs.getResultSet();
                    boolean esAdvertencia = SPUtil.tieneColumna(rs, "ADVERTENCIA");
                    while (rs.next()) {
                        if (esAdvertencia) {
                            System.out.println("Advertencia SP: " + rs.getString("ADVERTENCIA"));
                        } else {
                            lista.add(mapear_fila_solicitud(rs));
                        }
                    }
                } else if (cs.getUpdateCount() == -1) {
                    break;
                }
                tiene = cs.getMoreResults();
            }

            if (!cs.getBoolean(6)) {
                throw new IllegalArgumentException(cs.getString(5));
            }
        } catch (SQLException ex) {
            throw new SQLException("Error al buscar solicitudes: " + ex.getMessage(), ex);
        }
        return lista;
    }

    // ------------------------------------------------------------------
    // Escritura
    // ------------------------------------------------------------------

    /**
     * @return true si se cargó. Lanza IllegalStateException con el texto del SP si este rechazó la
     *         operación (p. ej. "ya tiene una solicitud pendiente").
     */
    public static boolean carga_solicitud(Integer id_cliente, String nombre, Double ingresos, Double gastos) throws SQLException, IOException {
        // Solicitud.ingresoAcutla y el parámetro Ingreso_IN son INT: se redondea explícitamente.
        long ingresoEntero = Math.round(ingresos);
        if (ingresoEntero > Integer.MAX_VALUE) {
            throw new IllegalArgumentException("El ingreso indicado es demasiado grande.");
        }
        try (CallableStatement cs = ConexionBDD.cn.prepareCall(SP_SOLICITAR)) {
            cs.setInt(1, id_cliente);
            cs.setString(2, nombre);
            cs.setInt(3, (int) ingresoEntero);
            cs.setDouble(4, gastos);

            boolean tiene = cs.execute();
            String adv = SPUtil.advertencia(cs, tiene);
            if (adv != null) {
                Logs_Intermedio.intermedio_carga_logs(id_cliente, "Solicitud rechazada por la BDD: " + adv, "SolicitudBDD: carga_solicitud()", false);
                throw new IllegalStateException(adv);
            }
            return true;

        } catch (SQLException e) {
            Logs_Intermedio.intermedio_carga_logs(id_cliente, "Error al insertar la solicitud: " + e.getMessage(), "SolicitudBDD: carga_solicitud()", false);
            throw new SQLException("Error al insertar la solicitud en la base de datos: " + e.getMessage(), e);
        }
    }

    /**
     * @param opcion 1 = Aprobado, 0 = Rechazado.
     * @return false si el SP advirtió que no se puede cambiar (p. ej. "ya fue gestionada").
     */
    public static boolean asignador_estado(Integer idSoli, int opcion, Integer id_responsable) throws IOException, SQLException {
        if (opcion != 0 && opcion != 1) {
            throw new IllegalArgumentException("Opción inválida: use 1 (aprobar) o 0 (rechazar).");
        }
        String estado = (opcion == 1) ? Solicitud.APROBADO : Solicitud.RECHAZADO;

        try (CallableStatement cs = ConexionBDD.cn.prepareCall(SP_ASIGNADOR)) {
            cs.setInt(1, idSoli);
            cs.setString(2, estado);
            cs.setInt(3, id_responsable);

            boolean tiene = cs.execute();
            String adv = SPUtil.advertencia(cs, tiene);
            if (adv != null) {
                Logs_Intermedio.intermedio_carga_logs(id_responsable, "Asignador_Estado rechazó el cambio de la solicitud " + idSoli + ": " + adv, "SolicitudBDD: asignador_estado()", false);
                return false;
            }
            return true;

        } catch (SQLException e) {
            Logs_Intermedio.intermedio_carga_logs(id_responsable, "Error en asignador_estado() para ID " + idSoli + ": " + e.getMessage(), "SolicitudBDD: asignador_estado()", false);
            throw new SQLException("Error al intentar cambiar el estado de la solicitud: " + e.getMessage(), e);
        }
    }
}