package BDD;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Utilidades comunes para interpretar lo que devuelven los stored procedures.
 * Los SP avisan las validaciones con un "SELECT 'texto' AS ADVERTENCIA" en lugar
 * de lanzar excepciones, por lo que hay que leerlas explícitamente.
 */
final class SPUtil {

    private SPUtil() {}

    static boolean tieneColumna(ResultSet rs, String nombreColumna) {
        try {
            rs.findColumn(nombreColumna);
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Recorre todos los resultados del statement ya ejecutado y devuelve el texto
     * de la primera ADVERTENCIA encontrada, o null si el SP no emitió ninguna.
     * Debe llamarse justo después de cs.execute(), pasando su valor de retorno.
     * Deja consumidos todos los result sets, por lo que luego se pueden leer los OUT.
     */
    static String advertencia(CallableStatement cs, boolean tieneResultados) throws SQLException {
        boolean actual = tieneResultados;
        while (true) {
            if (actual) {
                ResultSet rs = cs.getResultSet();
                if (rs != null && tieneColumna(rs, "ADVERTENCIA") && rs.next()) {
                    return rs.getString("ADVERTENCIA");
                }
            } else if (cs.getUpdateCount() == -1) {
                return null;
            }
            actual = cs.getMoreResults();
        }
    }

    /** Devuelve el primer String de las columnas indicadas que exista en el ResultSet (o null). */
    static String getString(ResultSet rs, String... nombres) throws SQLException {
        for (String n : nombres) {
            if (tieneColumna(rs, n)) {
                return rs.getString(n);
            }
        }
        return null;
    }

    /** Devuelve el primer double de las columnas indicadas que exista (o 0 si ninguna existe). */
    static double getDouble(ResultSet rs, String... nombres) throws SQLException {
        for (String n : nombres) {
            if (tieneColumna(rs, n)) {
                return rs.getDouble(n);
            }
        }
        return 0d;
    }
}