package BDD;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.util.Base64;

import Modelo.Cargo;
import Modelo.Empresa;
import Modelo.Persona;
import Modelo.Usuario;
import Servicio.Logs_Intermedio;

public class UsuarioBDD {

    public static final String OPERACION_EXITOSA = "¡Operación exitosa!";
    public static final int MAX_INTENTOS = 3;
    private static final int ID_ADMIN = 1;
    private static final String CLAVE_PLACEHOLDER = "CAMBIAR_CLAVE"; // la que deja Inicializador()

    /** Si historial es NULL (cliente sin solicitudes) se interpreta con este valor. */
    private static final boolean HISTORIAL_NULO_COMO = true;

    // ---------- SP que existen en Script_unificado_de_refrito_creditos ----------
    private static final String SP_INICIALIZADOR      = "{CALL Credito.Inicializador()}";
    private static final String SP_BUSCAR_USUARIOS    = "{CALL Credito.Buscar_Usuarios(?,?,?)}";    // IN (Nombre, Clave, ID_Usuario[log]); sin OUT
    private static final String SP_EXTRACTOR_USUARIOS = "{CALL Credito.Extractor_Usuarios(?)}";     // IN (ID) -> idUsuarioAcceso, nombreUsuario, clave, salt, numeroIntentos, ultimoIntento
    private static final String SP_REINICIAR_INTENTOS = "{CALL Credito.Reiniciador_Intentos(?)}";   // resetea solo si el último intento fue hace > 7 días
    private static final String SP_CREAR_USUARIO      = "{CALL Credito.Crear_Usuario(?,?,?,?)}";    // IN (Nombre, Clave, Salt, ID_Usuario): solo acepta ID_Usuario = 1
    private static final String SP_CREAR_CLIENTE      = "{CALL Credito.Crear_Cliente(?,?,?,?,?)}";  // IN (Nombre, Tipo, Rubro, Director, ID_Usuario[log])
    private static final String SP_EXTRAER_PERSONA    = "{CALL Credito.Extraer_Persona(?)}";        // IN idPersona
    private static final String SP_EXTRAER_EMPRESA    = "{CALL Credito.Extraer_Empresa(?)}";        // IN idEmpresa
    // ---------- SP NUEVOS: se crean con Parches_SP.sql ----------
    private static final String SP_FALLO_INTENTO      = "{CALL Credito.Registrar_Intento_Fallido(?)}";
    private static final String SP_MODIFICAR_USUARIO  = "{CALL Credito.Modificar_Usuario(?,?,?,?,?)}"; // (ID, Nombre|NULL, Clave|NULL, Salt|NULL, ID_Actor)
    private static final String SP_ELIMINAR_USUARIO   = "{CALL Credito.Eliminar_Usuario(?,?)}";        // (ID, ID_Actor)

    private ConexionBDD conexionBDD;

    public UsuarioBDD() throws IOException, InvalidKeySpecException, NoSuchAlgorithmException, SQLException {
        this.conexionBDD = new ConexionBDD();
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    /** Ejecuta el SP y devuelve su ADVERTENCIA (null si salió bien). */
    private static String ejecutar(CallableStatement cs) throws SQLException {
        boolean tiene = cs.execute();
        return SPUtil.advertencia(cs, tiene);
    }

    private static void setIntONull(CallableStatement cs, int idx, Integer v) throws SQLException {
        if (v != null) { cs.setInt(idx, v); } else { cs.setNull(idx, Types.INTEGER); }
    }

    private static void setStrONull(CallableStatement cs, int idx, String v) throws SQLException {
        if (v != null) { cs.setString(idx, v); } else { cs.setNull(idx, Types.VARCHAR); }
    }

    /** Un fallo al escribir el log nunca debe tapar el error original. */
    private static void registrarLog(int id, String msg, String origen, boolean ok) {
        try {
            Logs_Intermedio.intermedio_carga_logs(id, msg, origen, ok);
        } catch (Exception e) {
            System.err.println("No se pudo escribir el log (" + origen + "): " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------
    // Arranque
    // ------------------------------------------------------------------

    /**
     * Asegura que exista el administrador (Inicializador es idempotente) y verifica que
     * Buscar_Usuarios responda. Buscar_Usuarios tiene 3 parámetros IN y ningún OUT.
     */
    public boolean llenaBase() {
        try {
            try (CallableStatement cs = ConexionBDD.cn.prepareCall(SP_INICIALIZADOR)) {
                String adv = ejecutar(cs);
                if (adv != null) {
                    System.err.println("Inicializador: " + adv);
                }
            }
            try (CallableStatement cs = ConexionBDD.cn.prepareCall(SP_BUSCAR_USUARIOS)) {
                cs.setNull(1, Types.VARCHAR);
                cs.setNull(2, Types.VARCHAR);
                cs.setNull(3, Types.INTEGER);
                String adv = ejecutar(cs);
                if (adv != null) {
                    System.err.println("llenaBase: " + adv);
                    return false;
                }
            }
            return true;
        } catch (SQLException e) {
            System.err.println("Error en llenaBase: " + e.getMessage());
            return false;
        }
    }

    /**
     * Arranque único: define la clave real del administrador mientras siga siendo la de
     * Inicializador() ('CAMBIAR_CLAVE'). Llamar una sola vez desde un main de instalación.
     */
    public static String definirClaveAdministrador(String nuevaClave) throws InvalidKeySpecException, NoSuchAlgorithmException, SQLException {
        if (nuevaClave == null || nuevaClave.length() < 8) {
            return "La clave del administrador debe tener al menos 8 caracteres.";
        }
        String claveActual = null;
        try (CallableStatement cs = ConexionBDD.cn.prepareCall(SP_EXTRACTOR_USUARIOS)) {
            cs.setInt(1, ID_ADMIN);
            if (cs.execute()) {
                ResultSet rs = cs.getResultSet();
                if (rs != null && rs.next()) {
                    claveActual = rs.getString("clave");
                }
            }
        }
        if (claveActual == null) {
            return "El administrador no existe. Ejecute llenaBase() primero.";
        }
        if (!CLAVE_PLACEHOLDER.equals(claveActual)) {
            return "El administrador ya tiene una clave definida.";
        }
        byte[] rando = Usuario.genera_random();
        try (CallableStatement cs = ConexionBDD.cn.prepareCall(SP_MODIFICAR_USUARIO)) {
            cs.setInt(1, ID_ADMIN);
            cs.setNull(2, Types.VARCHAR);
            cs.setString(3, Usuario.hasheador(nuevaClave, rando));
            cs.setString(4, Base64.getEncoder().encodeToString(rando));
            cs.setInt(5, ID_ADMIN);
            String adv = ejecutar(cs);
            return (adv != null) ? adv : OPERACION_EXITOSA;
        }
    }

    // ------------------------------------------------------------------
    // Autenticación
    // ------------------------------------------------------------------

    /** El admin se excluye: su constructor en el modelo fija numeroIntentos = 999. */
    public static boolean estaBloqueado(Usuario u) {
        if (u == null || u.obtRol() == Cargo.ADMINISTRADOR) {
            return false;
        }
        return u.obtNumIntentos() >= MAX_INTENTOS;
    }

    /**
     * @return el Usuario, o null si las credenciales son inválidas.
     * @throws IllegalStateException si la cuenta está bloqueada.
     */
    public Usuario autenticarUsuario(String nombreUsuario, String contrasena) throws SQLException {
        if (nombreUsuario == null || nombreUsuario.isBlank() || contrasena == null || contrasena.isEmpty()) {
            return null;
        }
        Integer id = buscar_usuario(nombreUsuario);
        if (id == null) {
            return null;
        }

        // El SP resetea el contador solo si el último intento fue hace más de 7 días.
        reiniciarIntentos(id.intValue());

        Usuario u = buscar_usuario(id.intValue());
        if (u == null) {
            return null;
        }
        if (estaBloqueado(u)) {
            throw new IllegalStateException("Cuenta bloqueada por demasiados intentos fallidos. Intente nuevamente más adelante.");
        }

        boolean ok;
        try {
            ok = u.verificador_con(contrasena);
        } catch (IllegalArgumentException iae) { // clave/salt con formato inválido (p. ej. admin sin clave definida)
            registrarLog(id, "Clave/salt con formato inválido: " + iae.getMessage(), "UsuarioBDD: autenticarUsuario", false);
            return null;
        } catch (Exception e) {
            registrarLog(id, "Error verificando contraseña: " + e.getMessage(), "UsuarioBDD: autenticarUsuario", false);
            return null;
        }

        if (ok) {
            return u;
        }
        registrarIntentoFallido(id.intValue());
        return null;
    }

    private static void reiniciarIntentos(int idUsuario) throws SQLException {
        try (CallableStatement cs = ConexionBDD.cn.prepareCall(SP_REINICIAR_INTENTOS)) {
            cs.setInt(1, idUsuario);
            ejecutar(cs);
        }
    }

    private static void registrarIntentoFallido(int idUsuario) throws SQLException {
        try (CallableStatement cs = ConexionBDD.cn.prepareCall(SP_FALLO_INTENTO)) {
            cs.setInt(1, idUsuario);
            ejecutar(cs);
        }
    }

    // ------------------------------------------------------------------
    // Búsquedas
    // ------------------------------------------------------------------

    public static Usuario buscar_usuario(int id) throws SQLException {
        try (CallableStatement cs = ConexionBDD.cn.prepareCall(SP_EXTRACTOR_USUARIOS)) {
            cs.setInt(1, id);
            if (!cs.execute()) {
                return null;
            }
            ResultSet rs = cs.getResultSet();
            if (rs == null || !rs.next()) {
                return null;
            }

            int idAcceso = rs.getInt("idUsuarioAcceso");
            String nombre = rs.getString("nombreUsuario");
            String clave = rs.getString("clave");
            String salt = rs.getString("salt");
            int intentos = rs.getInt("numeroIntentos");
            java.sql.Date ult = rs.getDate("ultimoIntento");
            LocalDate ultimoIntento = (ult != null) ? ult.toLocalDate() : null;

            if (idAcceso == ID_ADMIN) {
                return new Usuario(nombre, clave, salt); // Constructor exclusivo del Administrador.
            }
            // UsuarioAcceso no está vinculado a UsuarioCliente/Persona/Empresa en el esquema actual:
            // el usuario se devuelve sin datos de cliente (ver nota sobre el vínculo).
            return new Usuario(idAcceso, nombre, clave, salt, false, intentos, ultimoIntento, null, null);

        } catch (SQLException ex) {
            registrarLog(id, "Error SQL: " + ex, "UsuarioBDD: buscar_usuario(int)", false);
            throw new SQLException("Ocurrió un error inesperado con SQL: " + ex, ex);
        }
    }

    /** @return idUsuarioAcceso del usuario con ese nombre, o null. */
    public static Integer buscar_usuario(String nom) throws SQLException {
        if (nom == null) {
            return null;
        }
        try (CallableStatement cs = ConexionBDD.cn.prepareCall(SP_BUSCAR_USUARIOS)) {
            cs.setString(1, nom);
            cs.setNull(2, Types.VARCHAR); // Clave_IN null = buscar solo por nombre
            cs.setNull(3, Types.INTEGER);
            if (cs.execute()) {
                ResultSet rs = cs.getResultSet();
                if (rs != null && SPUtil.tieneColumna(rs, "idUsuarioAcceso") && rs.next()) {
                    return Integer.valueOf(rs.getInt("idUsuarioAcceso"));
                }
            }
            return null;
        } catch (SQLException ex) {
            System.err.println("UsuarioBDD.buscar_usuario(String): " + ex.getMessage());
            throw new SQLException("Ocurrió un error inesperado con SQL: " + ex, ex);
        }
    }

    /** Toma la fila más reciente (el SP devuelve una fila por solicitud). */
    public static Persona cargarPersona(int idPersona) throws SQLException {
        try (CallableStatement cs = ConexionBDD.cn.prepareCall(SP_EXTRAER_PERSONA)) {
            cs.setInt(1, idPersona);
            ResultSet rs = cs.execute() ? cs.getResultSet() : null;
            if (rs != null && rs.next()) {
                return new Persona(rs.getString("nombre"), rs.getDouble("ingresos"), rs.getDouble("gastos"),
                        leerHistorial(rs), rs.getObject("fechaHistorial", LocalDate.class));
            }
            return null;
        }
    }

    public static Empresa cargarEmpresa(int idEmpresa) throws SQLException {
        try (CallableStatement cs = ConexionBDD.cn.prepareCall(SP_EXTRAER_EMPRESA)) {
            cs.setInt(1, idEmpresa);
            ResultSet rs = cs.execute() ? cs.getResultSet() : null;
            if (rs != null && rs.next()) {
                return new Empresa(rs.getString("nombre"), rs.getDouble("ingresos"), rs.getDouble("gastos"),
                        leerHistorial(rs), rs.getObject("fechaHistorial", LocalDate.class),
                        rs.getString("rubro"), rs.getString("director"));
            }
            return null;
        }
    }

    /** historial es VARCHAR(100): se lee como texto en lugar de getBoolean. */
    private static boolean leerHistorial(ResultSet rs) throws SQLException {
        String h = rs.getString("historial");
        if (h == null || h.isBlank()) {
            return HISTORIAL_NULO_COMO;
        }
        h = h.trim();
        return h.equalsIgnoreCase("true") || h.equals("1") || h.equalsIgnoreCase("si")
                || h.equalsIgnoreCase("sí") || h.equalsIgnoreCase("bueno");
    }

    // ------------------------------------------------------------------
    // Alta / baja / modificación
    // ------------------------------------------------------------------

    /**
     * Crear_Usuario solo acepta como ID_Usuario al administrador (1): idActor debe ser el de la sesión admin.
     * Los SP hacen su propio START TRANSACTION/COMMIT, así que no se envuelve en una transacción Java:
     * si Crear_Cliente falla se compensa borrando el usuario recién creado.
     */
    public static String registrar_datos_usuario(String nombre, String contrasena, Cargo cargo, String rubro, String director, Integer idActor) throws InvalidKeySpecException, NoSuchAlgorithmException, SQLException {
        String tipo;
        if (Cargo.EMPRESA.equals(cargo)) {
            tipo = "E";
            if (rubro == null || rubro.isBlank() || director == null || director.isBlank()) {
                return "Las empresas requieren rubro y director.";
            }
        } else if (Cargo.PERSONA.equals(cargo)) {
            tipo = "P";
            rubro = null;
            director = null;
        } else {
            return "Solo se pueden registrar clientes de tipo Persona o Empresa.";
        }

        byte[] rando = Usuario.genera_random();
        String rando64 = Base64.getEncoder().encodeToString(rando);
        String hash = Usuario.hasheador(contrasena, rando); // la contraseña en texto plano no vuelve a usarse

        try {
            try (CallableStatement cs = ConexionBDD.cn.prepareCall(SP_CREAR_USUARIO)) {
                cs.setString(1, nombre);
                cs.setString(2, hash);
                cs.setString(3, rando64);
                setIntONull(cs, 4, idActor);
                String adv = ejecutar(cs);
                if (adv != null) {
                    return adv;
                }
            }

            Integer idNuevo = buscar_usuario(nombre); // Crear_Usuario no devuelve el id
            if (idNuevo == null) {
                return "Ocurrió un error inesperado intentando cargar al usuario. Revise los Logs para más información";
            }

            String advCliente = null;
            try (CallableStatement cs = ConexionBDD.cn.prepareCall(SP_CREAR_CLIENTE)) {
                cs.setString(1, nombre);
                cs.setString(2, tipo);
                setStrONull(cs, 3, rubro);
                setStrONull(cs, 4, director);
                setIntONull(cs, 5, idActor);
                advCliente = ejecutar(cs);
            } catch (SQLException ex) {
                compensar(idNuevo, idActor);
                throw ex;
            }
            if (advCliente != null) {
                compensar(idNuevo, idActor);
                return advCliente;
            }

            registrarLog(idNuevo, "Se registró el usuario " + nombre, "UsuarioBDD: registrar_datos_usuario", true);
            return OPERACION_EXITOSA;

        } catch (SQLException ex) {
            System.err.println("registrar_datos_usuario: " + ex.getMessage());
            throw new SQLException("Ocurrió un error inesperado con SQL: " + ex, ex);
        }
    }

    private static void compensar(int idUsuario, Integer idActor) {
        try {
            eliminar_datos_usuario(idUsuario, idActor);
        } catch (SQLException e) {
            System.err.println("No se pudo revertir el alta del usuario " + idUsuario + ": " + e.getMessage());
        }
    }

    public static String eliminar_datos_usuario(int idUsuario) throws SQLException {
        return eliminar_datos_usuario(idUsuario, Integer.valueOf(idUsuario));
    }

    public static String eliminar_datos_usuario(int idUsuario, Integer idActor) throws SQLException {
        try (CallableStatement cs = ConexionBDD.cn.prepareCall(SP_ELIMINAR_USUARIO)) {
            cs.setInt(1, idUsuario);
            setIntONull(cs, 2, idActor);
            String adv = ejecutar(cs);
            return (adv != null) ? adv : OPERACION_EXITOSA;
        } catch (SQLException ex) {
            registrarLog(idUsuario, "Error SQL al eliminar: " + ex, "UsuarioBDD: eliminar_datos_usuario", false);
            throw new SQLException("Ocurrió un error inesperado con SQL al intentar eliminar un usuario: " + ex, ex);
        }
    }

    public static Usuario modificar_usuariobdd(Usuario actual, String nuevoNom, String nuevaCon) throws InvalidKeySpecException, NoSuchAlgorithmException, SQLException {
        int id = actual.obtIdUsuario();
        boolean hayNombre = (nuevoNom != null) && !nuevoNom.isBlank();
        boolean hayClave = (nuevaCon != null) && !nuevaCon.isBlank();

        String hash = null;
        String salt = null;
        if (hayClave) {
            byte[] rando = Usuario.genera_random();
            hash = Usuario.hasheador(nuevaCon, rando);
            salt = Base64.getEncoder().encodeToString(rando);
        }

        try (CallableStatement cs = ConexionBDD.cn.prepareCall(SP_MODIFICAR_USUARIO)) {
            cs.setInt(1, id);
            setStrONull(cs, 2, hayNombre ? nuevoNom : null);
            setStrONull(cs, 3, hash);
            setStrONull(cs, 4, salt);
            cs.setInt(5, id);
            String adv = ejecutar(cs);
            if (adv != null) {
                registrarLog(id, "Modificación rechazada: " + adv, "UsuarioBDD: modificar_usuariobdd", false);
                return actual;
            }
            Usuario recargado = buscar_usuario(id);
            return (recargado != null) ? recargado : actual;

        } catch (SQLException ex) {
            registrarLog(id, "Error SQL: " + ex, "UsuarioBDD: modificar_usuariobdd", false);
            throw new SQLException("Ocurrió un error inesperado con SQL: " + ex, ex);
        }
    }
}