package Servicio;

public class ReglaMaestra {

    public static double calcularMontoRMC3(Double ingresos, Double gastos) {

        double plataSobrante = ingresos - gastos;
        
        // Sacamos el 30% mensual y lo multiplicamos por 12 
        // para obtener el monto máximo del crédito a 1 año, por ejemplo.
        double montoMaximo = (plataSobrante * 0.30) * 12;

        return montoMaximo;
    }
}