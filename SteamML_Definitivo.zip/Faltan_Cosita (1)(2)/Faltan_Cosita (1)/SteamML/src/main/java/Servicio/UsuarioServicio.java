package Servicio;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.SQLException;

import BDD.UsuarioBDD;
import Modelo.Cargo;
import Modelo.Usuario;

public class UsuarioServicio {

    private static final String SOLO_LETRAS = "[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+";
    private static final String MSJ_NOMBRE_INVALIDO =
            "El nombre no sigue las reglas especificadas:\n debe ser únicamente texto, sin números ni caracteres especiales";

    private UsuarioBDD usbd;
    private Usuario usuarioActual;
    private String ultimoMensaje = "";

    public UsuarioServicio() {
        try {
            this.usbd = new UsuarioBDD();
            this.usbd.llenaBase();
        } catch (IOException e) {
            System.err.println("Error de entrada/salida al inicializar UsuarioBDD: " + e.getMessage());
        } catch (InvalidKeySpecException e) {
            System.err.println("Error de clave inválida (InvalidKeySpecException): " + e.getMessage());
        } catch (NoSuchAlgorithmException e) {
            System.err.println("Algoritmo criptográfico no encontrado (NoSuchAlgorithmException): " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("Error de base de datos (SQLException): " + e.getMessage());
        }
    }

    public boolean haySesion() {
        return this.usuarioActual != null;
    }

    public Usuario extractor() {
        return this.usuarioActual;
    }

    public String getUltimoMensaje() {
        return ultimoMensaje;
    }

    public int iniciar_sesion(String nombreUsuario, String contrasena) {
        if (this.usbd == null) {
            ultimoMensaje = "El sistema no pudo conectarse a la base de datos.";
            return -1;
        }
        try {
            Usuario usr = usbd.autenticarUsuario(nombreUsuario, contrasena);
            if (usr != null) {
                this.usuarioActual = usr;
                ultimoMensaje = "Sesión iniciada.";
                return usr.obtIdUsuario();
            }
            ultimoMensaje = "Usuario o contraseña incorrectos.";
        } catch (IllegalStateException ise) { // cuenta bloqueada
            ultimoMensaje = ise.getMessage();
        } catch (Exception ex) {
            System.err.println("Error durante inicio de sesión: " + ex.getMessage());
            ultimoMensaje = "Ocurrió un error durante el inicio de sesión.";
        }
        return -1;
    }

    public void cerrar_sesion() {
        this.usuarioActual = null;
    }

    public int obtenerIDUsuario() {
        if (!haySesion()) {
            throw new IllegalStateException("No hay una sesión activa de usuario.");
        }
        return this.usuarioActual.obtIdUsuario();
    }

    public String obtenerNomUs() {
        if (!haySesion()) {
            throw new IllegalStateException("No hay una sesión activa de usuario.");
        }
        return this.usuarioActual.obtNomUs();
    }

    public String realizar_bus_us(String id) throws SQLException {
        int id_fin;
        try {
            id_fin = Integer.parseInt(id.trim());
        } catch (NumberFormatException | NullPointerException nfe) {
            return "Error de formato";
        }

        Usuario encontrado = UsuarioBDD.buscar_usuario(id_fin);
        if (encontrado != null) {
            this.usuarioActual = encontrado;
            return "Usuario encontrado: " + encontrado.obtNomUs();
        }
        return "No se encontró ningún usuario con esos datos.";
    }

    public String realizar_bus_us(String nom, String con) throws InvalidKeySpecException, NoSuchAlgorithmException, SQLException, IOException {
        if (nom == null || nom.isBlank()) {
            return "Debe indicar el nombre de usuario.";
        }
        if (con == null || con.isEmpty()) {
            return "Debe indicar la contraseña.";
        }

        Integer id = UsuarioBDD.buscar_usuario(nom);
        if (id == null) {
            return "Usuario no encontrado";
        }

        Usuario candidato = UsuarioBDD.buscar_usuario(id.intValue());
        if ((candidato != null) && candidato.verificador_con(con)) {
            return "Se encontró dicho usuario con ID: " + candidato.obtIdUsuario();
        }
        return "Usuario no encontrado";
    }

    public String registrar_usuario(String nom, String cont, Cargo carg) throws InvalidKeySpecException, NoSuchAlgorithmException, SQLException {
        return registrar_usuario(nom, cont, carg, null, null);
    }

    /** rubro y director solo se usan (y son obligatorios) para empresas. */
    public String registrar_usuario(String nom, String cont, Cargo carg, String rubro, String director) throws InvalidKeySpecException, NoSuchAlgorithmException, SQLException {
        if ((nom == null) || nom.isBlank() || (cont == null) || cont.isBlank() || (carg == null)) {
            return "Registro inválido. Complete todos los campos solicitados, por favor.";
        }
        if (!nom.matches(SOLO_LETRAS)) {
            return "Registro inválido. " + MSJ_NOMBRE_INVALIDO;
        }
        if (UsuarioBDD.buscar_usuario(nom) != null) {
            return "Nombre de usuario en uso";
        }

        // Se devuelve el resultado real de la BDD (antes se respondía siempre "registrado correctamente").
        // Crear_Usuario solo acepta al administrador (ID 1) como actor: se pasa el usuario en sesión (null si no hay).
        Integer idActor = haySesion() ? Integer.valueOf(this.usuarioActual.obtIdUsuario()) : null;
        String resultado = UsuarioBDD.registrar_datos_usuario(nom, cont, carg, rubro, director, idActor);
        if (UsuarioBDD.OPERACION_EXITOSA.equals(resultado)) {
            return "Se registró correctamente el usuario en la base de datos.";
        }
        return resultado;
    }

    public String eliminarUsuario() throws SQLException {
        if (!haySesion()) {
            return "Aún no se cargó el usuario en el sistema. Por favor, inicie sesión para continuar.";
        } else if (this.usuarioActual.obtIdUsuario() == 1) {
            return "No se puede eliminar al Administrador del sistema.";
        }

        String msj = UsuarioBDD.eliminar_datos_usuario(this.usuarioActual.obtIdUsuario());
        if (UsuarioBDD.OPERACION_EXITOSA.equals(msj)) {
            this.usuarioActual = null;
        }
        return msj;
    }

    public String modificar_usr(String nom, String contra) throws InvalidKeySpecException, NoSuchAlgorithmException, SQLException {
        if (!haySesion()) {
            return "Aún no se cargó el usuario en el sistema.";
        }

        boolean cambiaNombre = (nom != null) && !nom.isBlank() && !nom.equals(this.usuarioActual.obtNomUs());
        boolean cambiaContra = (contra != null) && !contra.isBlank() && !this.usuarioActual.verificador_con(contra);

        if ((nom != null) && !nom.isBlank() && !nom.matches(SOLO_LETRAS)) {
            return "Modificación inválida. " + MSJ_NOMBRE_INVALIDO;
        }
        if (!cambiaNombre && !cambiaContra) {
            return "Modificación inválida. El nombre y la contraseña no pueden ser iguales a los actuales.";
        }

        if (cambiaNombre && (UsuarioBDD.buscar_usuario(nom) != null)) {
            Logs_Intermedio.intermedio_carga_logs(this.usuarioActual.obtIdUsuario(), "El nombre ingresado ya existe en el sistema", "UsuarioServicio: modificar_usr", false);
            return "Modificación inválida. Los datos ingresados ya existen en el sistema. El nombre es único por cuenta.";
        }

        Usuario actualizado = UsuarioBDD.modificar_usuariobdd(this.usuarioActual,
                cambiaNombre ? nom : null,
                cambiaContra ? contra : null);

        boolean nombreOk = !cambiaNombre || nom.equals(actualizado.obtNomUs());
        boolean contraOk = !cambiaContra || actualizado.verificador_con(contra);

        if (nombreOk && contraOk) {
            this.usuarioActual = actualizado;
            return "¡Se cambió correctamente la información del usuario!";
        }
        return "Ocurrió un error inesperado al intentar modificar al usuario. Revise los Logs para más información";
    }
}