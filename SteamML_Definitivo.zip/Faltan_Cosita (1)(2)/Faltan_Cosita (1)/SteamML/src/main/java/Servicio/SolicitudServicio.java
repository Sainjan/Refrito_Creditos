package Servicio;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.regex.Pattern;

import BDD.SolicitudBDD;
import BDD.UsuarioBDD;
import Modelo.Solicitud;
import Modelo.Usuario;

public class SolicitudServicio {

    private static final Pattern SOLO_LETRAS = Pattern.compile("^[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]+$");

    SolicitudBDD solbd;

    public SolicitudServicio() {
        this.solbd = new SolicitudBDD();
    }

    public static Solicitud informe(Integer id_soli) throws SQLException {
        return SolicitudBDD.extractor_sol(id_soli);
    }

    public static double calcular_monto_maximo(Solicitud s) {
        return ReglaMaestra.calcularMontoRMC3(s.obtIngresos(), s.obtGastos());
    }

    
    public static boolean solicitar_credito(Integer idUsuario, String nombre, String ingresosVerificar, String gastosVerificar) throws IOException, SQLException {

        if (idUsuario == null) {
            throw new IllegalStateException("No hay un usuario con sesión activa.");
        }
        Usuario usuarioActual = UsuarioBDD.buscar_usuario(idUsuario);
        if (usuarioActual == null) {
            throw new IllegalStateException("El usuario indicado no existe o fue dado de baja.");
        }
        if (UsuarioBDD.estaBloqueado(usuarioActual)) {
            return false;
        }

        if (nombre == null || !SOLO_LETRAS.matcher(nombre).matches()) {
            throw new IllegalArgumentException("El nombre debe contener únicamente letras y espacios.");
        }
        nombre = nombre.trim();

        double ingreso;
        double gasto;
        try {
            ingreso = Double.parseDouble(ingresosVerificar.trim());
            gasto = Double.parseDouble(gastosVerificar.trim());
        } catch (NumberFormatException | NullPointerException e) {
            throw new NumberFormatException("Error al procesar los valores numéricos: " + e.getMessage());
        }
        if (!Double.isFinite(ingreso) || !Double.isFinite(gasto) || ingreso < 0 || gasto < 0) {
            throw new IllegalArgumentException("Los saldos deben ser números válidos y no pueden ser negativos.");
        }

        // El estado y la fecha los fija el SP; si este advierte (p. ej. "ya tiene una solicitud pendiente")
        // carga_solicitud lanza IllegalStateException con ese texto.
        if (!SolicitudBDD.carga_solicitud(idUsuario, nombre, ingreso, gasto)) {
            return false;
        }

        Logs_Intermedio.intermedio_carga_logs(idUsuario, "Solicitud cargada exitosamente en la base de datos.", "SolicitudServicio: solicitar_credito", true);
        return true;
    }

    private static int parsearId(String id) {
        int idSoli;
        try {
            idSoli = Integer.parseInt(id.trim());
        } catch (NumberFormatException | NullPointerException e) {
            throw new NumberFormatException("El formato del ID es inválido. Ingrese un número entero positivo.");
        }
        if (idSoli <= 0) {
            throw new IllegalArgumentException("ID indicado inválido. Por favor, ingrese un valor entero positivo.");
        }
        return idSoli;
    }

    /** Detalle de una solicitud en cualquier estado (para consulta). */
    public static Solicitud detalle_solicitud(String id_seleccionado) throws SQLException {
        Solicitud s = SolicitudBDD.extractor_sol(parsearId(id_seleccionado));
        if (s == null) {
            throw new IllegalArgumentException("No se encontró una solicitud con ese ID.");
        }
        return s;
    }

    /** Detalle de una solicitud solo si sigue 'Pendiente' (para gestionar). */
    public static Solicitud expande_solicitud(String id_seleccionado) throws SQLException {
        Solicitud s = SolicitudBDD.extractor_sol(parsearId(id_seleccionado));
        if (s != null && s.estaPendiente()) {
            return s;
        }
        throw new IllegalArgumentException("No se encontró una solicitud pendiente con ese ID y estado aún 'Pendiente'.");
    }


    public static ArrayList<Solicitud> mostrar_creditos(boolean ban, String estado, String fecha, char criterioFecha) throws SQLException {
        try {
            LocalDate fec_real = LocalDate.parse(fecha);
            return SolicitudBDD.buscarSolicitudes(ban, estado, fec_real, criterioFecha);
        } catch (DateTimeParseException dtpe) {
            throw new DateTimeParseException("Formato de fecha inválido (use yyyy-MM-dd): " + dtpe.getMessage(), String.valueOf(fecha), 0);
        }
    }


    @Deprecated
    public static ArrayList<Solicitud> mostrar_creditos(boolean ban, String estado, String fecha, Integer id_responsable, boolean decide_men_mas) throws SQLException {
        return mostrar_creditos(ban, estado, fecha, decide_men_mas ? '>' : '<');
    }

    public static ArrayList<Solicitud> mostrar_creditos(String estado, String fecha, Integer id_responsable, boolean decide_men_mas) throws SQLException {
        return mostrar_creditos(false, estado, fecha, decide_men_mas ? '>' : '<');
    }

    public static boolean segregador(Integer id_cambia, boolean op, Integer id_responsable) throws IOException, SQLException {
        Solicitud fila;
        try {
            fila = SolicitudBDD.extractor_sol(id_cambia);
        } catch (IllegalArgumentException iae) {
            Logs_Intermedio.intermedio_carga_logs(id_responsable, "No se pudo obtener la solicitud " + id_cambia + ": " + iae.getMessage(), "SolicitudServicio: segregador", false);
            return false;
        }

        if (fila == null || !fila.estaPendiente()) {
            return false;
        }

        int decision = op ? 1 : 0;
        String nuevoEstado = op ? Solicitud.APROBADO : Solicitud.RECHAZADO;

        if (SolicitudBDD.asignador_estado(id_cambia, decision, id_responsable)) {
            fila.setEstado(nuevoEstado);
            Logs_Intermedio.intermedio_carga_logs(id_responsable, "Se cambió exitosamente el estado de la solicitud ID = " + id_cambia + " a '" + nuevoEstado + "'", "SolicitudServicio: segregador", true);
            return true;
        }

        // asignador_estado ya registró el motivo (advertencia del SP) en los logs.
        return false;
    }
}