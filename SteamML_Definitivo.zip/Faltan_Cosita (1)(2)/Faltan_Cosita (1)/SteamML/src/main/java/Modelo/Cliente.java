package Modelo;

import java.time.LocalDate;

//Cliente implementa FuncionCalculo para que Usuario y Solicitud puedan evaluar el riesgo de forma polimórfica (Persona o Empresa).
public abstract class Cliente implements FuncionCalculo {

    protected String nombre;
    protected double ingresos, gastos; //Protegidos: solamente los trata el paquete y las hijas de "Cliente".
    protected boolean buenHistorial;
    protected LocalDate fechaHistorial;

    protected Cliente(String nom, double ing, double gastosC, boolean historial, LocalDate fecHis)
    {
        this.nombre = nom;
        this.ingresos = ing;
        this.gastos = gastosC;
        this.buenHistorial = historial;
        this.fechaHistorial = fecHis;
    }

    public String obtNombre()
    {
        return this.nombre;
    }

    public double obtIngresos()
    {
        return this.ingresos;
    }

    public double obtGastos()
    {
        return this.gastos;
    }

    public boolean obtHistorial()
    {
        return this.buenHistorial;
    }

    public LocalDate obtFecHis()
    {
        return this.fechaHistorial;
    }

}