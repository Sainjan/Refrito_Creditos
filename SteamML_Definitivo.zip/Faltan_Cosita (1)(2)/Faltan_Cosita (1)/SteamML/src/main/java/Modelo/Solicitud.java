package Modelo;

import java.sql.SQLException;
import java.time.LocalDate;

import Servicio.ReglaMaestra;

public class Solicitud{

    public static final String PENDIENTE = "Pendiente";
    public static final String APROBADO = "Aprobado";
    public static final String RECHAZADO = "Rechazado";


    Integer idSolicitud; 
    int idCliente;
    double ingresos, gastos, montoMaximo;
    LocalDate fecha; 
    String estado;
    Usuario solicitante;

    public Solicitud(Integer idSolicitud, double ingresos, double gastos, String estado, LocalDate fecha, Usuario solicitante) throws SQLException {
        this.idSolicitud = idSolicitud;
        this.ingresos = ingresos;
        this.gastos = gastos;

        this.estado = normalizarEstado(estado);
 
        if (fecha != null) {
            this.fecha = fecha;
        } else {
            this.fecha = LocalDate.now(); 
        }

        this.solicitante = solicitante;
    }

    /** Constructor para filas devueltas por los SP (que traen idCliente y la fecha como texto yyyy-MM-dd). */
    public Solicitud(int idSolicitud, int idCliente, double ingresos, double gastos, String estado, String fecha) {
        this.idSolicitud = idSolicitud;
        this.idCliente = idCliente;
        this.ingresos = ingresos;
        this.gastos = gastos;
        this.estado = normalizarEstado(estado);
        this.fecha = (fecha != null && !fecha.isBlank())
                ? LocalDate.parse(fecha.trim().substring(0, Math.min(10, fecha.trim().length())))
                : LocalDate.now();
    }

    public int obtIdCliente() {
        return this.idCliente;
    }

    private static String normalizarEstado(String estado) {
        if (estado != null) {
            if (estado.equalsIgnoreCase(APROBADO) || estado.equalsIgnoreCase("Confirmado")) { //"Confirmado" era el nombre antiguo de "Aprobado".
                return APROBADO;
            } else if (estado.equalsIgnoreCase(RECHAZADO)) {
                return RECHAZADO;
            }
        }
        return PENDIENTE;
    }

    public Integer obtIdSolicitud() {
        return this.idSolicitud;
    }


    public double obtIngresos(){
        return this.ingresos;
    }

    public double obtGastos(){
        return this.gastos;
    }

    public String obtEstado(){
        return this.estado;
    }

    public boolean estaPendiente() {
        return PENDIENTE.equals(this.estado);
    }


    public LocalDate obtFecha(){
        return this.fecha;
    }

    public void setEstado(String nuevoEstado){
        this.estado = nuevoEstado;
    }

    public Usuario obtSolicitante() {
        return this.solicitante;
    }


    public boolean evaluarRiesgo() {
        if (this.solicitante == null) { //Solicitante no cargado: no se puede evaluar, se descarta.
            return false;
        }
        return this.solicitante.evaluaRiesgo();
    }

    public void setSolicitante(Usuario solicitante) {
        this.solicitante = solicitante;
    }
 

    public double getMontoMaximo() {
        return ReglaMaestra.calcularMontoRMC3(this.ingresos, this.gastos);
    }

    
}