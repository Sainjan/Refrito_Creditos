/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.java.BDD;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import main.java.Modelo.Usuario;


public class UsuarioBDD {

    Usuario nuevo;

    public UsuarioBDD() throws IOException, InvalidKeySpecException, NoSuchAlgorithmException, SQLException
    {
        llena_base();
    }
    
    private void llena_base() throws InvalidKeySpecException, NoSuchAlgorithmException, SQLException
    {
        try
        {
            String consulta_inicializa = "{CALL SteaMLBDD.Inicializador()}";

            CallableStatement proceso = ConexionBDD.cn.prepareCall(consulta_inicializa);
            proceso.execute();

            String busca_usuarios = "{CALL SteaMLBDD.Buscar_Usuarios(?,?,?,?)}";
            
            CallableStatement listador = ConexionBDD.cn.prepareCall(busca_usuarios);
            listador.setNull(1,java.sql.Types.VARCHAR);
            listador.setNull(2,java.sql.Types.VARCHAR);
            listador.setNull(3,java.sql.Types.VARCHAR);
            listador.setNull(4, java.sql.Types.INTEGER);

            listador.execute();

            ResultSet resultado_bus = listador.getResultSet();

            if(!resultado_bus.next())
            {
                //this.registrar_datos_usuario("SA", "Sapo_Pepe123", "00000000", true);
            } else
            {
                do
                {
                    int valor_id_fila = resultado_bus.getObject("ID_Usuario",Integer.class);

                    String verificador_intentos = "{CALL SteaMLBDD.Reiniciador_Intentos(?)}";

                    CallableStatement verifica_ultimo_intento = ConexionBDD.cn.prepareCall(verificador_intentos);
                    verifica_ultimo_intento.setInt(1,valor_id_fila);

                    verifica_ultimo_intento.execute();
                } while(resultado_bus.next());
            }
        } catch (NumberFormatException nfe) {
            throw new NumberFormatException("Ocurrió un error inesperado con el formato numérico ingresado");
        } catch (DateTimeParseException dtpe)
        {
            throw new DateTimeParseException("Ocurrió un error inesperado con el formato de la fecha cargado", null, 0);
        } catch (SQLException sqle)
        {
            throw new SQLException("Ocurrió un error inesperado al intentar ejecutar un proceso SQL: " + sqle);
        }
    }

    public String buscar_usuario(Integer id) throws SQLException {

        try
        {

            String consulta = "{CALL SteaMLBDD.Extractor_Usuarios(?)}";

            CallableStatement buscador = ConexionBDD.cn.prepareCall(consulta);


            int id_int = id;

            buscador.setInt(1,id_int);

            buscador.execute();

            ResultSet resultado_bus = buscador.getResultSet();

            String msj;

            if(resultado_bus.next())
            {
                String nom_sql = resultado_bus.getObject("Nombre",String.class);
                int id_rol_sql = resultado_bus.getInt("ID_Rol");
                int id_est_us_sql = resultado_bus.getInt("ID_Estado_Usuario");

                String car = "Cliente";
                if(id_rol_sql == 2)
                {
                    car = "Administrador";
                }

                if(id_est_us_sql == 2)
                {
                    return "El usuario buscado no existe en el sistema";
                }

                msj = "¡Se encontró al usuario buscado!\nNombre: " + nom_sql + "\nCargo: " + car;
            } else
            {
                msj = "El usuario buscado no existe en el sistema";
            }

            return msj;
        } catch (SQLException sqlex_bus)
        {
            throw new SQLException("Ocurrió un error inesperado con SQL: " + sqlex_bus,sqlex_bus);
        }
    }

    public String buscar_usuario(String nom, String contra, String dni) throws IOException, InvalidKeySpecException, NoSuchAlgorithmException, SQLException {

        try
        {
            String consulta = "{CALL SteaMLBDD.Buscar_Usuarios(?,?,?,?)}";

            CallableStatement buscador = ConexionBDD.cn.prepareCall(consulta);

            if(nom != null)
            {
                buscador.setString(1,nom);
            } else
            {
                buscador.setNull(1,java.sql.Types.VARCHAR);
            }

            //HASHEO DE CONTRASEÑA. NO ES MUY ÓPTIMO, PERO HAY QUE HACERLO
            if(contra != null)
            {
                byte[] rando = genera_random();

                String contra_hash = hasheador(contra, rando);

                buscador.setString(2,contra_hash);
            } else
            {
                buscador.setNull(2,java.sql.Types.VARCHAR);
            }

            //DNI DE USUARIO
            if(dni != null)
            {
                buscador.setString(3,dni);
            } else
            {
                buscador.setNull(3,java.sql.Types.VARCHAR);
            }

            if(Usuario.id.equals(0))
            {
                buscador.setNull(4,java.sql.Types.INTEGER);
            } else
            {
                int id_us_int = Usuario.id;
                buscador.setInt(4,id_us_int);
            }

            buscador.execute();

            ResultSet resultado = buscador.getResultSet();

            if(!resultado.next())
            {
                return "No se encontró ningún usuario con esos datos";
            } else
            {
                if((nom != null) && (contra == null) && (dni == null))
                {
                    return "El nombre ingresado está en uso";
                }

                if((nom == null) && (contra == null) && (dni != null))
                {
                    int id_obtenido = resultado.getInt("ID_Usuario");
                    return "El DNI está en uso" + String.valueOf(id_obtenido);
                }

                if((nom != null) && (contra == null) && (dni != null))
                {
                    int id_obtenido = resultado.getInt("ID_Usuario");
                    return "El usuario existe" + String.valueOf(id_obtenido);
                }

                if((nom != null) && (contra != null) && (dni != null))
                {
                    int id_obtenido = resultado.getInt("ID_Usuario");
                    int id_est_us_sql = resultado.getInt("ID_Estado_Usuario");
                    if(id_est_us_sql == 2)
                    {
                        return "No se encontró ningún usuario con esos datos";
                    }
                    return "¡Se encontró al usuario buscado!" + String.valueOf(id_obtenido);
                }

                return "No se encontró ningún usuario con esos datos";
            }
        } catch (SQLException sqlex)
        {
            throw new SQLException("Ocurrió un error inesperado con SQL: " + sqlex,sqlex);
        }
    }

    public Usuario extrae_us(Integer id) throws SQLException {

        try
        {
            String consulta_extrae = "{CALL SteaMLBDD.Extractor_Usuarios(?)}";

            CallableStatement llamador = ConexionBDD.cn.prepareCall(consulta_extrae);

            int id_us_int = Usuario.id;
            llamador.setInt(1,id_us_int);

            llamador.execute();

            ResultSet resultado_bus = llamador.getResultSet();

            if(resultado_bus.next())
            {
                int id_us_sql = resultado_bus.getInt("ID_Usuario");
                String nom_sql = resultado_bus.getObject("Nombre",String.class);
                String con_sql = resultado_bus.getObject("Contrasena", String.class);
                String dni_sql = resultado_bus.getObject("DNI",String.class);
                String salt_sql = resultado_bus.getObject("Salt",String.class);
                int num_int_sql = resultado_bus.getInt("Numero_Intentos");
                LocalDate fec_sql = resultado_bus.getObject("Ultimo_Intento",LocalDate.class);
                int id_rol_sql = resultado_bus.getInt("ID_Rol");
                int id_est_us_sql = resultado_bus.getInt("ID_Estado_Usuario");

                boolean cargo = false;
                if(id_rol_sql == 2)
                {
                    cargo = true;
                }

                boolean estado = true;
                if(id_est_us_sql == 2)
                {
                    estado = false;
                }

                this.nuevo.settea_datos(nom_sql, con_sql, dni_sql,salt_sql,cargo,num_int_sql,fec_sql,estado);
            } else
            {
                throw new IllegalArgumentException("El ID buscado no existe en el sistema");
            }

            return this.nuevo;
        } catch(SQLException sqlex)
        {
            throw new SQLException("Ocurrió un error inesperado con SQL: " + sqlex,sqlex);
        }

    }

    public String registrar_datos_usuario(String nombre, String contrasena, String dni, boolean cargo) throws IOException, InvalidKeySpecException, NoSuchAlgorithmException, SQLException {

        String consulta_creador = "{CALL SteaMLBDD.Crear_Usuarios(?,?,?,?,?)}";
        try {

            int estado;
            if(cargo) {
                estado = 2;
            } else {
                estado = 1;
            }

            byte[] rando = genera_random();

            String rando64 = Base64.getEncoder().encodeToString(rando);
            String contra_hash = hasheador(contrasena, rando);

            CallableStatement procedimiento = ConexionBDD.cn.prepareCall(consulta_creador);

            procedimiento.setString(1,nombre);
            procedimiento.setString(2,contra_hash);
            procedimiento.setString(3,dni);
            procedimiento.setString(4,rando64);
            procedimiento.setInt(5,estado);

            procedimiento.execute();

            String resultado_busca = buscar_usuario(nombre, contrasena, dni);

            if(resultado_busca.contains("Se encontró al usuario buscado"))
            {
                return "¡Operación exitosa!";
            } else
            {
                return "Ocurrió un error inesperado intentando cargar al usuario. Revise los Logs para más información";
            }

        } catch (IOException ioex) {

            Logs_Intermedio.intermedio_carga_logs(Usuario.id, "Ocurrió un error inesperado al intentar abrir el archivo de UsuarioBDD.txt: " + ioex, "UsuarioBDD: registrar_datos_usuario", false);
            throw new IOException("Ocurrió un error inesperado al intentar abrir el archivo de UsuarioBDD.txt: ", ioex);
        } catch (SQLException sqlex_reg)
        {
            throw new SQLException("Ocurrió un error inesperado con SQL: " + sqlex_reg,sqlex_reg);
        }
    }

    public String eliminar_datos_usuario(Integer id_usuario) throws IOException, SQLException
    {
        try
        {
            String consulta_borrador = "{CALL SteaMLBDD.Eliminar_Usuarios(?)}";

            CallableStatement llamador = ConexionBDD.cn.prepareCall(consulta_borrador);


            int id_int = id_usuario;
            llamador.setInt(1,id_int);

            llamador.execute();

            String resultado = buscar_usuario(Usuario.id);
            if(resultado.contains("El usuario buscado no existe en el sistema"))
            {
                return "Operación exitosa";
            } else
            {
                return "Ocurrió un error inesperado al intentar eliminar al usuario del sistema. Revise el Log para más información";
            }
        } catch(SQLException sqlex_el)
        {
            throw new SQLException("Ocurrió un error inesperado con SQL: " + sqlex_el,sqlex_el);
        }
    }

    public String modificar_usuariobdd(Integer id_usuario, String nuevo_nombre, String nueva_contrasena) throws IOException, InvalidKeySpecException, NoSuchAlgorithmException, SQLException{
        int id_int = id_usuario;

        Usuario registro = extrae_us(id_usuario);
                
        String resultado_busca_id = buscar_usuario(id_usuario);
        if(resultado_busca_id.contains("El usuario buscado no existe en el sistema"))
        {
            Logs_Intermedio.intermedio_carga_logs(Usuario.id, "El usuario indicado no existe en el sistema", "modificar_usuariobdd", false);
            return "Error: El usuario no existe en los registros";
        }

        if(!buscar_usuario(nuevo_nombre, null, null).contains("No se encontró ningún usuario con esos datos.")) {
            Logs_Intermedio.intermedio_carga_logs(Usuario.id, "El nombre ingresado ya existe en el sistema", "UsuarioBDD: modificar_usuariobdd", false);
            return "Error: Los datos ingresados ya existen en el sistema. El nombre es único por cuenta.";
        }

        try
        {
            String contra_def;
            String salt_def;
            if(nueva_contrasena != null) {
                byte[] rando = genera_random();

                String hash64 = hasheador(nueva_contrasena, rando);
                String contra_hash = new String(Base64.getDecoder().decode(hash64));

                salt_def = hash64;
                contra_def = contra_hash;
            } else
            {
                salt_def = registro.rando;
                contra_def = registro.contrasena;
            }

            String nombre_def;
            if(nuevo_nombre != null) {
                nombre_def = nuevo_nombre;
            } else
            {
                nombre_def = registro.nombre;
            }
            
            String consulta_modifica = "{CALL SteaMLBDD.Modificar_Usuario(?,?,?,?)}";

            CallableStatement llamador = ConexionBDD.cn.prepareCall(consulta_modifica);

            llamador.setInt(1,id_int);
            llamador.setString(2,nombre_def);
            llamador.setString(3,contra_def);
            llamador.setString(4,salt_def);

            llamador.execute();

            String resultado_consulta = buscar_usuario(nombre_def,contra_def,registro.dni);

            if(resultado_consulta.contains("Se encontró al usuario buscado"))
            {
                return "Usuario modificado exitosamente";
            } else
            {
                return "Ocurrió un error inesperado al intentar modificar al usuario. Para más información, lea el Log";
            }
        } catch (InvalidKeySpecException ikse)
        {
            throw new InvalidKeySpecException("Ocurrió un error inesperado al intentar cifrar la contraseña: ",ikse);
        } catch(NoSuchAlgorithmException nsue) {
            throw new NoSuchAlgorithmException("Ocurrió un error inesperado con el algoritmo de encriptación: ",nsue);
        } catch (SQLException sqlex_mod)
        {
            throw new SQLException("Ocurrió un error inesperado con SQL: " + sqlex_mod,sqlex_mod);
        }
    }
}