/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.java.Servicio;

import java.io.IOException;
//IMPORTS DE HASHEO
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import main.java.Modelo.Usuario;
import main.java.BDD.UsuarioBDD;

public class UsuarioServicio {

    UsuarioBDD usbd;

    public UsuarioServicio(UsuarioBDD usbdd) {
        this.usbd = usbdd;
    }

    //INICIO DE HASHEADORES========================================================================================================

    private byte[] genera_random()
    { //Genera una secuencia random para ser utilizada en el hasheo. Es única por usuario, por lo que se almacena en UsuarioBDD.txt
        SecureRandom random = new SecureRandom(); //SecureRandom es un random aún más aleatorio e impredecible que otros random. Raro, lo sé...
        byte[] saleo = new byte[16];
        random.nextBytes(saleo);
        return saleo;
    }

    private String hasheador(String contra, byte[] randomizer) throws InvalidKeySpecException, NoSuchAlgorithmException
    {
        
        try
        {
            int vueltas = 65536; //Cuantas más iteraciones, más tiempo tarda y más difícil sería para un usuario externo averiguar el salt (comando randomizador) correcto rápidamente
            int longitud_final = 256; //Longitud de bytes finales
            char[] caracteres = contra.toCharArray(); //String es una cadena guardada de forma imprecisa; hacer arreglos de char permite mayor definición y seguridad

            PBEKeySpec contenedor = new PBEKeySpec(caracteres, randomizer, vueltas, longitud_final); //Se pasan los parámetros de la contraseña a un "contenedor"
            SecretKeyFactory solicita = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256"); //Se solicita un procesamiento de clave especial para el algoritmo indicado
            
            byte[] encriptador = solicita.generateSecret(contenedor).getEncoded(); //Procesa la contraseña con su randomizer según el algoritmo indicado
            
            return Base64.getEncoder().encodeToString(encriptador); //La contraseña hasheada de por sí es un valor de bytes difícil de manejar.
                                                                    //Pasarla a Base64 permite leerla como texto plano
        } catch (InvalidKeySpecException ikse)
        {
            throw new InvalidKeySpecException("Ocurrió un error inesperado: La contraseña indicada tiene un formato inválido: " + ikse.getMessage(),ikse);
        } catch (NoSuchAlgorithmException nsue)
        {
            throw new NoSuchAlgorithmException("Ocurrió un error inesperado con el algoritmo de encriptación: " + nsue,nsue);
        }
    }

    public boolean verificador_con(String contra) throws InvalidKeySpecException, NoSuchAlgorithmException
    {
        
        try
        {
            byte[] saleo_act = Base64.getDecoder().decode(this.salt); //Se obtiene el formato de randomización para que sea igual al de la contraseña
            
            String hash_contra = hasheador(contra, saleo_act); //Se hashea la contraseña con el formato de randomización para verificar si es igual
            
            return MessageDigest.isEqual(hash_contra.getBytes(StandardCharsets.UTF_8), this.contrasena.getBytes(StandardCharsets.UTF_8)); //El MessageDigest brinda mayor seguridad ante filtraciones,
                                                                                                                                      //pues evita que se identifique el hasheo por tiempo de proceso
        } catch(InvalidKeySpecException ikse) 
        {
            throw new InvalidKeySpecException("Ocurrió un error inesperado al intentar solicitar una clave: ",ikse);
        } catch(NoSuchAlgorithmException nsue) 
        {
            throw new NoSuchAlgorithmException("Ocurrió un error inesperado con el algoritmo de encriptación: ",nsue);
        }
    }

    //FIN DE HASHEADORES===============================================================================================================


    public Usuario extractor(Integer id_int) throws SQLException {
        Usuario buscado = this.usbd.extrae_us(id_int);

        return buscado;
    }

    public static String realizar_bus_us(String id) throws SQLException{

        Integer id_fin = 0;
        try {
            id_fin = Integer.parseInt(id);
        } catch (NumberFormatException nfe) {
            return "Error de formato";
        }
        
        String msj = Usuario.usbd.buscar_usuario(id_fin);

        return msj;
    }

    public static String realizar_bus_us(String nom, String con, String dni_d) throws InvalidKeySpecException, NoSuchAlgorithmException, SQLException, IOException {
        return Usuario.usbd.buscar_usuario(nom, con, dni_d);
    }

    public static String registrar_usuario(String nom, String cont, String dni_d,boolean carg) throws IOException, InvalidKeySpecException, NoSuchAlgorithmException, SQLException {

        if((nom == null) || (dni_d == null) || (cont == null))
        {
            return "Registro inválido. Complete todos los campos solicitados, por favor.";
        }
        String buscador = realizar_bus_us(nom, null, null); //Se busca solamente el nombre y el dni pues son los dos datos que no se pueden repetir

        String busca_dos = realizar_bus_us(null,null,dni_d);

        if((!buscador.contains("No se encontró ningún usuario con esos datos")) || (!busca_dos.contains("No se encontró ningún usuario con esos datos"))) {
            return "Nombre: " + buscador + "\nDNI: " + busca_dos;
        } else
        {
            String respuesta = Usuario.usbd.registrar_datos_usuario(nom,cont,dni_d,carg);
            return respuesta;
        }
    }

    public static Integer iniciar_sesion(String nom, String con, String dni_d) throws IOException, InvalidKeySpecException, NoSuchAlgorithmException, SQLException{

        String buscador = realizar_bus_us(nom, null, null); //Se busca solamente el nombre y el dni pues son los dos datos que no se pueden repetir

        String busca_dos = realizar_bus_us(null,null,dni_d);

        if((buscador.contains("El nombre ingresado está en uso")) && (busca_dos.contains("El DNI está en uso"))) { //Se espera esto porque la contraseña buscada es null; pues primero es preferible comparar que exista el usuario y después se hace el proceso de comparación de hasheos

            String permitido = String.valueOf(busca_dos.substring(18));

            try
            {
            
                Integer id_int = Integer.parseInt(permitido);
                Usuario busca = extractor(id_int);

                if(UsuarioBDD.verificador_con(con, busca.contrasena, busca.rando)) {

                    Usuario.id = id_int;
                    Logs_Intermedio.intermedio_carga_logs(Usuario.id, "El usuario " + Usuario.id.toString() + " inició sesión correctamente", "Usuario: iniciar_sesion", true);
                    return id_int;
                }

            } catch(NumberFormatException nfe)
            {
                Logs_Intermedio.intermedio_carga_logs(Usuario.id, "Ocurrió un error inesperado al intentar comparar la información del usuario", "Usuario: Inicio sesión", false);
                throw new NumberFormatException("Ocurrió un error inesperado al intentar comparar la información del ID de usuario: ");
            }

        }

        return -1;

    }

    public static String eliminar_usuario(String id_ingresado)throws IOException, SQLException {
        Integer id_usuario;
        String msj;
        try{
            id_usuario = Integer.parseInt(id_ingresado);
        }catch(NumberFormatException nfe){
            return "El ID debe ser numérico";
        }
        String verificar = realizar_bus_us(id_ingresado);
        if (verificar.contains("El usuario buscado no existe")) {
            return "El ID a eliminar no existe en los registros";
        }
        msj = Usuario.usbd.eliminar_datos_usuario(id_usuario);
        return msj;
    }
    
    public static String modificar_usr(Integer id_busca, String nom, String contra)throws IOException, InvalidKeySpecException, NoSuchAlgorithmException, SQLException {

        String msj = Usuario.usbd.buscar_usuario(id_busca);
        if(!msj.contains("El usuario buscado no existe en el sistema")){
            msj = Usuario.usbd.modificar_usuariobdd(id_busca, nom, contra);
        }
        return msj;
    }
}