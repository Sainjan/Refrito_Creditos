package main.java.Modelo;

public class Persona extends Cliente implements FuncionCalculo {

    public Persona(String nombre, double ingresos, double gastos, boolean buenHistorial){
        super(nombre, ingresos, gastos, buenHistorial);   
    }
    

    @Override 
    public boolean evaluarRiesgo(){

    }
}