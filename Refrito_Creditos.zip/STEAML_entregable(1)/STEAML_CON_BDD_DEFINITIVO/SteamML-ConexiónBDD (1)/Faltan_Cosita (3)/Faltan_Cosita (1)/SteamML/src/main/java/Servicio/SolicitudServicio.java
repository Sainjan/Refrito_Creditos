package main.java.Servicio;
 
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
 
public class SolicitudServicio {
    
    // ATRIBUTOS DE LA CLASE
    Integer idSolicitud;               
    Integer idUsuarioResponsable;
    static SolicitudBDD solbd;
    LocalDate fecha;
    
    // Del dataset
    String genero;                 
    String auto;                   
    String propiedad;              
    String telefonoTrabajo;        
    String telefono;               
    String email;                  
    String desempleo;              
    Integer hijos;                     
    Integer familia;                   
    Integer longitudCuenta;            
    Double ingresosAnuales;        
    Integer edad;                      
    Integer aniosEmpleado;         
    String empleo;                 
    String origenIngresos;         
    String educacion;              
    String estadoCivil;            
    String estadoCasa;             
    String ocupacion;              
    
    // Del formulario
    Double gastoMensual;           
    String hipoteca;               
    String valores;                
    String deposito;               
    String bancoOnline;            
    String tarjetaCredito;         
    
    // De la Red Neuronal
    Double monto;                  
    Double porcentajeAprobacion;       
    String estado;
 
    public Solicitud(Integer id_nue, String[] respuesta) throws SQLException {
        this.idSolicitud = id_nue;
 
        // Mapeo del dataset
        this.genero = respuesta[1].trim();
        this.auto = respuesta[2].trim();
        this.propiedad = respuesta[3].trim();
        this.telefonoTrabajo = respuesta[4].trim();
        this.telefono = respuesta[5].trim();
        this.email = respuesta[6].trim();
        this.desempleo = respuesta[7].trim();
 
        this.hijos = Integer.parseInt(respuesta[8].trim());
        this.familia = Integer.parseInt(respuesta[9].trim());
        this.longitudCuenta = Integer.parseInt(respuesta[10].trim());
        this.ingresosAnuales = Double.parseDouble(respuesta[11].trim());
        this.edad = Integer.parseInt(respuesta[12].trim());
 
        this.aniosEmpleado = Integer.parseInt(respuesta[13].trim());
        this.empleo = respuesta[14].trim();
        this.educacion = respuesta[15].trim();
        this.estadoCivil = respuesta[16].trim();
        this.estadoCasa = respuesta[17].trim();
        this.ocupacion = respuesta[18].trim();
 
        // Mapeo del formulario
        this.origenIngresos = respuesta[19].trim();
        this.gastoMensual = Double.parseDouble(respuesta[20].trim());
        this.hipoteca = respuesta[21].trim();
        this.valores = respuesta[22].trim();
        this.deposito = respuesta[23].trim();
        this.bancoOnline = respuesta[24].trim();
        this.tarjetaCredito = respuesta[25].trim();
 
        // De la Red Neuronal
        this.monto = Double.parseDouble(respuesta[26].trim()); 
 
        // Estado
        if (respuesta.length > 27 && !respuesta[27].trim().isEmpty()) {
            this.estado = respuesta[27].trim();
        } else {
            this.estado = "Pendiente";
        }
 
        if (respuesta.length > 28 && !respuesta[28].trim().isEmpty()) {
            try {
                this.idUsuarioResponsable = Integer.parseInt(respuesta[28].trim());
            } catch (NumberFormatException e) {
                // Manejo por si la posición 28 no es un número (por ejemplo, si fuera la fecha)
            }
        }
 
        // Fecha
        if (respuesta.length > 29 && !respuesta[29].trim().isEmpty()) {
            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            this.fecha = LocalDate.parse(respuesta[29].trim(), formato);
        } else {
            this.fecha = LocalDate.now(); 
        }
    }
 
    public Solicitud(SolicitudBDD solb)
    {
        Solicitud.solbd = solb;
    }
 
    public static Solicitud informe(Integer id_soli) throws SQLException {
        return SolicitudBDD.extractor_sol(id_soli);
    }
    
    public static boolean solicitar_credito(String[] respuesta, Integer idUsuario) throws IOException, SQLException {
        Usuario usuarioActual = Usuario.extractor(idUsuario); 
 
        if (usuarioActual != null && usuarioActual.numero_intentos >= 3) {
            return false;
        }
        
        for (int i = 0; i < respuesta.length; i++){
            if(respuesta[i].trim().isEmpty() || respuesta[i] == null){
                throw new IllegalArgumentException("En el campo N°" + (i + 1) + " está incompleto.");
            }
        }
       
        try{
            double[] entradas = datos_normalizados(respuesta); 
        }catch(NumberFormatException e){
            throw new IllegalArgumentException("Los campos de cantidad deben ser numéricos, o los campos SI/NO deben tener uno de esos dos valores. Detalle: " + e.getMessage());
        }
        
        if(!SolicitudBDD.carga_solicitud(respuesta, idUsuario))
        {
            return false;
        }
        Logs_Intermedio.intermedio_carga_logs(idUsuario, "Solicitud cargada exitosamente en la base de datos.", "Solicitud: solicitar_credito", true);
        return true;
    }
    
    public static Solicitud expande_solicitud(String id_seleccionado) throws SQLException {
        int idSoli;
        try {
            idSoli = Integer.parseInt(id_seleccionado.trim());
            if (idSoli <= 0) {
                throw new IllegalArgumentException("ID indicado inválido. Por favor, ingrese un valor entero positivo.");
            }
        } catch (NumberFormatException e) {
            throw new NumberFormatException("El formato del ID es inválido. Ingrese un número entero positivo.");
        }
 
        Solicitud solicitudEncontrada = SolicitudBDD.extractor_sol(idSoli);
 
        if (solicitudEncontrada != null && solicitudEncontrada.estado.equals("Pendiente")) {
            return solicitudEncontrada;
        } else {
            throw new IllegalArgumentException("No se encontró una solicitud pendiente con ese ID y estado aún 'Pendiente'.");
        }
    }
 
    public static ArrayList<Solicitud> mostrar_creditos(String estado, String fecha, Integer id_responsable, boolean decide_men_mas) throws SQLException, IOException, Exception
    {
        try
        {
            LocalDate fec_real = LocalDate.parse(fecha);
            
            return SolicitudBDD.buscar_solicitudes(false,estado, fec_real, id_responsable, decide_men_mas);
 
        } catch (DateTimeParseException dtpe)
        {
            throw new DateTimeParseException("Ocurrió un error inesperado con el formato de la fecha ingresada: " + dtpe,"",0);
        }
    }
 
    public static boolean segregador(Integer id_cambia, boolean op) throws IOException, SQLException
    {
        Solicitud fila = SolicitudBDD.extractor_sol(id_cambia);
 
        if (fila == null) {
            return false;
        }
 
        int decision = 0;
        String valor_aprueba = "'Rechazado'";
        if(op)
        {
            decision = 1;
            valor_aprueba = "'Aprobado'";
        }
        
        double valor_rn = 0.0;
        if(!fila.porcentajeAprobacion.equals(0.0))
        {
            valor_rn = fila.porcentajeAprobacion;
        }
 
        if(SolicitudBDD.asignador_estado(id_cambia, decision, valor_rn))
        {
            if (decision == 1){
                fila.estado =  "Aprobado";
            }else{
                fila.estado = "Rechazado";
            }
            
            if (valor_rn != 0.0) {
                fila.porcentajeAprobacion = valor_rn;
            }
            
            Logs_Intermedio.intermedio_carga_logs(Usuario.id, "Se cambió exitosamente el estado de la solicitud ID = " + id_cambia.toString() + " a " + valor_aprueba, "Solicitud: segregador", true);
            return true;
 
        } else
        {
            Logs_Intermedio.intermedio_carga_logs(Usuario.id, "Ocurrió un error inesperado al intentar cambiar el estado de la solicitud", "SolicitudBDD: asignador_estado", false);
            return false;
        }
    }
 
    /**
     * Traduce un valor SI/NO 
     */
    private static double convertirSiNo(String valor, String nombreCampo) {
        String v = valor.trim().toUpperCase().replace("Í", "I");
        if (v.equals("SI") || v.equals("YES") || v.equals("1")) {
            return 1.0;
        } else if (v.equals("NO") || v.equals("0")) {
            return 0.0;
        } else {
            throw new NumberFormatException("El campo '" + nombreCampo + "' debe ser SI o NO (valor recibido: '" + valor + "')");
        }
    }
    
    public static double[] datos_normalizados(String[] datos) {
        double[] entradas = new double[18];
        entradas[0] = convertirSiNo(datos[1].trim(), "Genero");           // Gender
        entradas[1] = convertirSiNo(datos[2].trim(), "Auto");             // Own_car  
        entradas[2] = convertirSiNo(datos[3].trim(), "Propiedad");        // Own_property
        entradas[3] = convertirSiNo(datos[4].trim(), "Telefono_Trabajo"); // Work_phone
        entradas[4] = convertirSiNo(datos[5].trim(), "Telefono");         // Phone
        entradas[5] = convertirSiNo(datos[6].trim(), "Email");            // Email
        entradas[6] = convertirSiNo(datos[7].trim(), "Desempleo");        // Unemployed
                    
        Integer num_children = Integer.parseInt(datos[8].trim());
        if(num_children < 0){
            throw new IllegalArgumentException("El numero de hijos no puede ser menor a 0");
        }else{
            if (num_children == 0){
                entradas[7] = 1.0;
            }else{
                entradas[7] = 1.0 / num_children; 
            }
        }   
                
        Integer num_family = Integer.parseInt(datos[9].trim());
        if(num_family < 0 || num_family > 10){
            throw new IllegalArgumentException("El numero de hijos no puede ser menor a 0 o mayor a 10");
        }else{
            if (num_family == 0){
                entradas[8] = 1.0;
            }else{
                entradas[8] = 1.0 / num_family;
            }
        }
                    
        entradas[9] = Double.parseDouble(datos[10].trim()); // Account_length
        if(entradas[9] < 1 || entradas[9] > 80){
            throw new IllegalArgumentException("La antiguedad de la cuenta no puede ser 0 o menor");
        }else{
            entradas[9] = entradas[9] / 100;
        }
                
        entradas[10] = Double.parseDouble(datos[11].trim()) / 1000000.0;
                
        entradas[11] = Double.parseDouble(datos[12].trim());
        if (entradas[11] < 18 || entradas[11] > 100){
            throw new IllegalArgumentException("Los años de edad no pueden ser menor a 18 o mayor a 100");
        }else{
            entradas[11] = entradas[11] / 100.0;
        }
                
        entradas[12] = Double.parseDouble(datos[13].trim()); // Years_employed
        if(entradas[12] < 1 || entradas[12] > 50){
            throw new IllegalArgumentException("Los años de experiencia no puede ser 0 o menor");
        }else{
            entradas[12] = entradas[12] / 50.0;
        }
                  
        String incomeType = datos[14].trim();
        switch (incomeType) {
            case "Working":
                entradas[13] = 1.0;
                break;
            case "State servant":
                entradas[13] = 0.9;
                break;
            case "Commercial associate":
                entradas[13] = 0.7;
                break;
            case "Pensioner":
                entradas[13] = 0.4;
                break;
            case "Student":
                entradas[13] = 0.2;
                break;
            default:
                entradas[13] = 0.5; 
                break;
        }
                    
        String education = datos[15].trim();
        switch (education) {
            case "Academic degree":
                entradas[14] = 1.0;
                break;
            case "Higher education":
                entradas[14] = 0.8;
                break;
            case "Incomplete higher":
                entradas[14] = 0.6;
                break;
            case "Secondary / secondary special":
                entradas[14] = 0.4;
                break;
            case "Lower secondary":
                entradas[14] = 0.1;
                break;
            default:
                entradas[14] = 0.4;
                break;
        }
                    
        String family_status = datos[16].trim();
        switch (family_status) {
            case "Married":
                entradas[15] = 1.0;
                break;
            case "Civil marriage":
                entradas[15] = 0.8;
                break;
            case "Widow":
                entradas[15] = 0.5;
                break;
            case "Single / not married":
                entradas[15] = 0.3;
                break;
            case "Separated":
                entradas[15] = 0.2;
                break;
            default:
                entradas[15] = 0.5; 
                break;
        }
                    
 
        String housing_type = datos[17].trim();
        switch (housing_type) {
            case "House / apartment":
                entradas[16] = 1.0;
                break;
            case "Co-op apartment":
                entradas[16] = 0.8;
                break;
            case "Municipal apartment":
                entradas[16] = 0.6;
                break;
            case "Office apartment":
                entradas[16] = 0.5;
                break;
            case "With parents":
                entradas[16] = 0.3; 
                break;
            case "Rented apartment":
                entradas[16] = 0.2; 
                break;
            default:
                entradas[16] = 0.5;
                break;
        }
                    
        String occupation = datos[18].trim();
        if (occupation.equalsIgnoreCase("Managers") || occupation.equalsIgnoreCase("High skill tech staff")) {
            entradas[17] = 1.0;
        } else if (occupation.equalsIgnoreCase("Other")) {
            entradas[17] = 0.2;
        } else {
            entradas[17] = 0.6; 
        }
            
        return entradas;
    }
    
} 
 

