package main.java.BDD;
 
//IMPORTS DE ARCHIVOS
 
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
 
public class SolicitudBDD {
 
    //private static Map<Integer, Solicitud> registro_sol = new HashMap<>();
    Integer id_soli = 0;
 
    public SolicitudBDD() throws IOException, SQLException
    {
        //llena_base_sol();
    }
    
        private static String[] extraer_datos_fila(ResultSet rs) throws SQLException {
        Integer id_solicitud = rs.getInt("ID_Solicitud");
 
        String[] datos = new String[29];
        datos[0]  = String.valueOf(id_solicitud);
        datos[1]  = rs.getString("Genero");
        datos[2]  = rs.getString("Auto");
        datos[3]  = rs.getString("Propiedad");         
        datos[4]  = rs.getString("Telefono_Trabajo");
        datos[5]  = rs.getString("Telefono");
        datos[6]  = rs.getString("Email");
        datos[7]  = rs.getString("Desempleo");
        datos[8]  = String.valueOf(rs.getInt("Hijos"));
        datos[9]  = String.valueOf(rs.getInt("Familia"));
        datos[10] = String.valueOf(rs.getInt("Longitud_Cuenta"));
        datos[11] = String.valueOf(rs.getInt("Ingresos_Anuales"));
        datos[12] = String.valueOf(rs.getInt("Edad"));
        datos[13] = rs.getString("Empleo");
        datos[14] = rs.getString("Origen_Ingresos");
        datos[15] = rs.getString("Educacion");
        datos[16] = rs.getString("Estado_Civil");
        datos[17] = rs.getString("Estado_Casa");        
        datos[18] = rs.getString("Ocupacion");
        datos[19] = String.valueOf(rs.getDouble("Gasto_Mensual"));
        datos[20] = rs.getString("Hipoteca");           
        datos[21] = rs.getString("Valores");           
        datos[22] = rs.getString("Deposito");           
        datos[23] = rs.getString("Banco_Online");       
        datos[24] = rs.getString("Tarjeta_Credito");    
        datos[25] = String.valueOf(rs.getDouble("Porcentaje_Aprobacion"));
        datos[26] = rs.getString("Estado");
        datos[27] = String.valueOf(rs.getInt("ID_Usuario_Responsable"));
        datos[28] = rs.getString("Fecha");
 
        return datos;
    }
 
    private static Solicitud mapear_fila_solicitud(ResultSet rs) throws SQLException {
        String[] datos = extraer_datos_fila(rs);
        Integer id_solicitud = Integer.valueOf(datos[0]);
        return new Solicitud(id_solicitud, datos);
    }
 
    
    
    public static Solicitud extractor_sol(Integer id_sol) throws SQLException{
        String sql = "{CALL SteaMLBDD.Extractor_Solicitud(?, ?, ?)}";
 
        try (CallableStatement cs = ConexionBDD.cn.prepareCall(sql)) {
            cs.setInt(1, id_sol);
            cs.registerOutParameter(2, java.sql.Types.BOOLEAN); 
            cs.registerOutParameter(3, java.sql.Types.VARCHAR); 
 
            ResultSet rs = cs.executeQuery();    
 
            boolean exito = cs.getBoolean(2);
            String mensaje = cs.getString(3);
 
            // 1. Si falló en MySQL, lanzamos la excepción con el mensaje
            if (!exito) {
                throw new IllegalArgumentException(mensaje);
            }
 
            // 2. Si fue exitoso y trae filas
            if (rs.next()) {
                Solicitud soli = SolicitudBDD.mapear_fila_solicitud(rs);
                return soli;
            }
 
            return null;
 
        } catch (SQLException e) {
            throw new SQLException("Error al intentar buscar la solicitud con ID " + id_sol + " en extractor_sol(): " + e.getMessage(), e);
        }
    }
 
    public static ArrayList<Solicitud> buscar_solicitudes(boolean ban, String est, LocalDate fecha, Integer id_resp, boolean men_mas_fec) throws SQLException, IOException, Exception
    {
        String sql = "{CALL SteaMLBDD.Buscar_Solicitudes(?, ?, ?, ?, ?, ?, ?)}";//dos parametros son OUT, por eso son 7
        ArrayList<Solicitud> lista_solis = new ArrayList<>();
 
        try (CallableStatement cs = ConexionBDD.cn.prepareCall(sql)) {
 
            cs.setBoolean(1, ban);
            cs.setString(2, est);
            if (fecha != null) {
                cs.setDate(3, java.sql.Date.valueOf(fecha));
            } else {
                cs.setNull(3, java.sql.Types.DATE);
            }
            cs.setInt(4, id_resp);
            cs.setBoolean(5, men_mas_fec);
            cs.registerOutParameter(6, java.sql.Types.BOOLEAN);
            cs.registerOutParameter(7, java.sql.Types.VARCHAR);
 
            ResultSet rs = cs.executeQuery();
 
            boolean exito = cs.getBoolean(6);
            String mensaje = cs.getString(7);
 
            if (!exito) {
                throw new IllegalArgumentException(mensaje);
            }
 
            if(ban) //ESTA RUTA ES PARA GESTIONAR SOLICITUDES
            {
                while (rs.next()) {
 
                    String[] datos = extraer_datos_fila(rs);
                    Integer id_solicitud = Integer.valueOf(datos[0]);
                    Solicitud fila = new Solicitud(id_solicitud, datos);
 
                    if(fila.estado.equals("Pendiente")) {
                        Double ingresos = (double) fila.ingresosAnuales;
                        Double integrantesFamilia = (double) fila.familia;
                        Double experiencia = (double) fila.longitudCuenta;
                        Double gasto = fila.gastoMensual;
 
   
                        Double eduNumerica = 1.0; // Valor por defecto
                        if (fila.educacion.equalsIgnoreCase("Secundario") || fila.educacion.equalsIgnoreCase("Carrera de grado")) {
                            eduNumerica = 3.0; // El valor que activa el bono del 5% en el PASO 1 de tu Regla Maestra
                        } else if (fila.educacion.equalsIgnoreCase("Secundario incompleto")) {
                            eduNumerica = 2.0;
                        }
 
    
                        Double tieneHipoteca = fila.hipoteca.equalsIgnoreCase("Sí") ? 1.0 : 0.0;
                        Double tieneDeposito = fila.deposito.equalsIgnoreCase("Sí") ? 1.0 : 0.0;
                        Double tieneValores = fila.valores.equalsIgnoreCase("Sí") ? 1.0 : 0.0;
                        Double tieneTarjeta = fila.tarjetaCredito.equalsIgnoreCase("Sí") ? 1.0 : 0.0;
 
 
                        double valida_monto = ReglaMaestra.calcularMontoRMC3(   
                            ingresos, integrantesFamilia, eduNumerica, experiencia, 
                            gasto, tieneHipoteca, tieneDeposito, tieneValores, tieneTarjeta
                        );
 
                        String valida_monto_str = String.valueOf(valida_monto);
                        Double valida_monto_wrapper = Double.parseDouble(valida_monto_str);
 
                        if(fila.monto <= valida_monto_wrapper) 
                        {
                            double[] entradasNormalizadas = Solicitud.datos_normalizados(datos);
                            double resultado_rn = RedNeuronal.gestionar_solicitud(entradasNormalizadas);
 
                            if(resultado_rn >= 0.75)
                            {
                                asignador_estado(id_solicitud, 2, resultado_rn); //Se le asigna como "opcion: 2" porque 
                                                                                // de ese modo se puede asignar el 
                                                                                // resultado de la Red Neuronal 
                                                                                // sin modificar el estado; 
                                                                                // esa tarea se deja al Administrador
                                lista_solis.add(fila);
                            } else 
                            {
                                if(fila.porcentajeAprobacion != 0)
                                {
                                    asignador_estado(id_solicitud, 0, 0);
                                } else 
                                {
                                    asignador_estado(id_solicitud, 0, resultado_rn); //Si se comprobó que el 
                                                                                // porcentaje de aprobación 
                                                                                // de Red Neuronal de la 
                                                                                // Solicitud es cero <0> 
                                                                                // y la Red Neuronal llegó 
                                                                                // a verificarla: 
                                                                                // se le asigna el valor 
                                                                                // resultante
                                }
                                Logs_Intermedio.intermedio_carga_logs(Usuario.id, "Se cambió el estado de la solicitud ID = " + id_solicitud + " a 'Rechazado' por no ser aprobado por la Red Neuronal","SolicitudBDD: buscar_solicitudes()",true);
                            }                                                                       
                        } else 
                        {
                            asignador_estado(id_solicitud, 0, 0); //Si la Solicitud ya tiene un porcentaje 
                            Logs_Intermedio.intermedio_carga_logs      // de aprobación != 0 o no fue validada por
                            (                                          // la Red Neuronal, conviene dejarlo en cero <0>
                            Usuario.id, 
                            "Se cambió el estado de la solicitud ID = " + id_solicitud + " a 'Rechazado' por no ser aprobado su monto",
                            "SolicitudBDD: buscar_solicitudes()",
                            true
                            );                                         
                                                                   
                        }
                    }
                    if((lista_solis != null) && (!lista_solis.isEmpty())) {
                        return lista_solis;
                    } else {
                        throw new IllegalArgumentException("La lista de solicitudes está vacía.");
                    }
                }   
            }else{ //ESTA OTRA RUTA ES PARA MOSTRAR SOLICITUDES
                 while (rs.next()) {
                    lista_solis.add(mapear_fila_solicitud(rs));
                 }    
            }//FIN DEL TRATAMIENTO DE BANDERAS
            
            if((lista_solis != null) && (!lista_solis.isEmpty())) {
                return lista_solis;
            } else {
                throw new IllegalArgumentException("La lista de solicitudes está vacía.");
            }
        }catch(SQLException e){
            throw new SQLException("Error al intentar buscar solicitudes en buscar_solicitudes(): " + e.getMessage(), e);
        } 
    }
    
    
    public static boolean carga_solicitud(String[] respuestas, Integer id_responsable) throws SQLException, IOException {
        String sql = "{CALL SteaMLBDD.Cargar_Solicitud(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";
 
        try (CallableStatement cs = ConexionBDD.cn.prepareCall(sql)) {
            cs.setString(1, respuestas[1]);                       // Genero
            cs.setString(2, respuestas[2]);                       // Auto
            cs.setString(3, respuestas[17]);                      // Estado_Casa
            cs.setString(4, respuestas[4]);                       // Telefono_Trabajo
            cs.setString(5, respuestas[5]);                       // Telefono
            cs.setString(6, respuestas[6]);                       // Email
            cs.setString(7, respuestas[7]);                       // Desempleo
            cs.setInt(8, Integer.parseInt(respuestas[8]));        // Hijos
            cs.setInt(9, Integer.parseInt(respuestas[9]));        // Familia
            cs.setInt(10, Integer.parseInt(respuestas[10]));      // Tiempo_Cuenta
            cs.setDouble(11, Double.parseDouble(respuestas[11])); // Ingresos_Anuales
            cs.setInt(12, Integer.parseInt(respuestas[12]));      // Edad
            cs.setInt(13, Integer.parseInt(respuestas[13]));      // Anios_Empleado
            cs.setString(14, respuestas[19]);                     // Origen_Ingresos (nueva posición; 14 ahora es Tipo de Ingreso, usado sólo por la Red Neuronal)
            cs.setString(15, respuestas[15]);                     // Educacion
            cs.setString(16, respuestas[16]);                     // Estado_Civil
            cs.setString(17, respuestas[3]);                      // Propiedad
            cs.setDouble(18, Double.parseDouble(respuestas[20])); // Gasto_Mensual
            cs.setString(19, respuestas[21]);                     // Hipoteca
            cs.setString(20, respuestas[22]);                     // Valores
            cs.setString(21, respuestas[23]);                     // Deposito
            cs.setString(22, respuestas[24]);                     // Banco_Online
            cs.setString(23, respuestas[25]);                     // Tarjeta_Credito
            cs.setDouble(24, Double.parseDouble(respuestas[26])); // Monto
            cs.setString(25, "Pendiente");                        // Estado_Solicitud
            cs.setInt(26, id_responsable);                        // ID_Usuario
            cs.setDouble(27, 0.0);                                // Porcentaje_Aprobacion inicial
 
            // Fecha actual
            LocalDate fechaActual = LocalDate.now();
            DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            cs.setString(28, fechaActual.format(formato));       // Fecha
 
            cs.execute();
 
            Logs_Intermedio.intermedio_carga_logs(
                id_responsable,
                "Se cargó correctamente la solicitud en la base de datos MySQL",
                "SolicitudBDD: carga_solicitud()",
                true
            );
 
            return true;
 
        } catch (SQLException e) {
            Logs_Intermedio.intermedio_carga_logs(
                id_responsable,
                "Error al intentar insertar la solicitud en MySQL: " + e.getMessage(),
                "SolicitudBDD: carga_solicitud()",
                false
            );
            throw new SQLException("Error al insertar la solicitud en la base de datos: " + e.getMessage(), e);
        }
    }
 
    
 
    public static boolean asignador_estado(Integer id, int opcion, double res_rn) throws IOException, SQLException
    {
        String estado = "Pendiente"; 
        if (opcion == 1) {                                                                                      
            estado = "Aprobado";                                                               
        } else if (opcion == 0) {                                                                                
            estado = "Rechazado";                                                              
        }                                                                                      
 
        String sql = "{CALL SteaMLBDD.Asignador_Estado(?, ?, ?)}";
 
        try (CallableStatement cs = ConexionBDD.cn.prepareCall(sql)) {
            cs.setInt(1, id);
            cs.setString(2, estado);
            cs.setDouble(3, res_rn);
 
            cs.execute();
            return true;
 
        } catch (SQLException e) {
            Logs_Intermedio.intermedio_carga_logs(
                Usuario.id, 
                "Ocurrió un error en asignador_estado() para ID " + id + ": " + e.getMessage(), 
                "SolicitudBDD: asignador_estado()", 
                false
            );
            throw new SQLException("Error al intentar cambiar el estado de la solicitud en MySQL: " + e.getMessage(), e);
        }
    }
}
    
 

