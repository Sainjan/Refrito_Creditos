package main.java.Servicio;

public class ReglaMaestra {

    public static double calcularMontoRMC3(Double income, Double family, Double education, 
                                          Double experience, Double ccAvg, Double mortgage, 
                                          Double cdAccount, Double securitiesAccount, Double creditCard) {
        
        // PASO 1: Factor DTI Base y Bonos de Confianza
        double dti = 0.35; // Base 35%
        if (education.equals(3.0)) {
            dti += 0.05;
        }
        if (cdAccount.equals(1.0)) {
            dti += 0.05;
        }
        if (securitiesAccount.equals(1.0)) {
            dti += 0.03;
        }

        // PASO 2: Penalización Familiar (PF)
        double pf = 0;
        if (family.equals(4.0)) {
            pf = -0.02;
        } else if (family.equals(5.0)) {
            pf = -0.05;
        } else if (family > 5.0) {
            pf = -0.05 - ((family - 5.0) * 0.02);
        }

        // PASO 3: Penalización por Estabilidad y Visibilidad (PS)
        double ps = 0;
        if (experience < 3.0) {
            ps -= 0.03;
        }
        if (creditCard.equals(0) && ccAvg > 4.0) {
            ps -= 0.03;
        }

        // PASO 4: El Mitigador por Ingresos (Inmunidad)
        double totalPenalizacion = pf + ps;
        if (income >= 192.0) {
            totalPenalizacion = 0;
        } else if (income > 150.0) {
            totalPenalizacion *= 0.5;
        }

        double dtiFinal = dti + totalPenalizacion;

        // PASO 5: Cálculo del Monto Final
        double im = income / 12; // Ingreso Mensual
        // CPD: Capacidad de Pago Disponible
        double cpd = (im * dtiFinal) - ccAvg - (mortgage * 0.007);

        if (cpd <= 0) {
            return 0.0;
        }

        double montoCapacidad = cpd * 30;
        double montoSeguridad = im * 10; // Tope de 10 sueldos

        // El resultado final es el menor de ambos límites
        double montoFinal = Math.min(montoCapacidad, montoSeguridad);

        // Retornar en dólares absolutos (el dataset usa escala de miles)
        // Se redondea a 2 decimales siguiendo el estándar financiero
        return Math.round(montoFinal * 1000 * 100.0) / 100.0; //No lo toco por miedo a romperlo, pero esto está raro: ¿Multiplico x100 y divido x100? Eso debería cancelarse, ciertamente...
    }
}