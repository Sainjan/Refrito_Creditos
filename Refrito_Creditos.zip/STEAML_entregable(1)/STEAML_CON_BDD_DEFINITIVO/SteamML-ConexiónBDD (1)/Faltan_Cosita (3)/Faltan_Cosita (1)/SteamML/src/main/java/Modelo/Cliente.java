package main.java.Modelo;

public abstract class Cliente {

    protected String nombre;
    protected double ingresos, gastos; //Se hacen protegidos para que únicamente pueda hacederlo el paquete en sí.
    protected boolean buenHistorial;   //No tiene 

    protected Cliente(String nom, double ing, double gastosC, boolean historial)
    {
        this.nombre = nom;
        this.ingresos = ing;
        this.gastos = gastosC;
        this.buenHistorial = historial;
    }

    public String obtNombre()
    {
        return this.nombre;
    }

    public double obtIngresos()
    {
        return this.ingresos;
    }

    public double obtGastos()
    {
        return this.gastos;
    }

    public boolean obtHistorial()
    {
        return this.buenHistorial;
    }

}