/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.java.Servicio;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.SQLException;
import java.time.LocalDate;

public class UsuarioServicio {

    static UsuarioBDD usbd;

    String nombre, contrasena, dni, rando;
    boolean cargo, estado_usuario;
    static Integer id = 0;
    Integer numero_intentos;
    LocalDate ultimo_intento;

    public Usuario(String nom, String con, String dni_d,boolean est, Integer nuevo_id, String randomizador, Integer intentos, LocalDate ultimo) {
        this.nombre = nom;
        this.contrasena = con;
        this.dni = dni_d;
        this.cargo = est;
        Usuario.id = nuevo_id;
        this.rando = randomizador;
        this.numero_intentos = intentos;
        this.ultimo_intento = ultimo;
    }

    public Usuario(UsuarioBDD usbdd) {
        Usuario.usbd = usbdd;
    }

    public void settea_datos(String nom, String con, String dni_d, String randomizador, boolean cargo, Integer intentos, LocalDate ultimo, boolean est_us)
    {
        this.nombre = nom;
        this.contrasena = con;
        this.dni = dni_d;
        this.rando = randomizador;
        this.cargo = cargo;
        this.numero_intentos = intentos;
        this.ultimo_intento = ultimo;
        this.estado_usuario = est_us;
    }

    public static Usuario extractor(Integer id_int) throws SQLException {
        Usuario buscado = usbd.extrae_us(id_int);

        return buscado;
    }

    public static String realizar_bus_us(String id) throws SQLException{

        Integer id_fin = 0;
        try {
            id_fin = Integer.parseInt(id);
        } catch (NumberFormatException nfe) {
            return "Error de formato";
        }
        
        String msj = Usuario.usbd.buscar_usuario(id_fin);

        return msj;
    }

    public static String realizar_bus_us(String nom, String con, String dni_d) throws InvalidKeySpecException, NoSuchAlgorithmException, SQLException, IOException {
        return Usuario.usbd.buscar_usuario(nom, con, dni_d);
    }

    public static String registrar_usuario(String nom, String cont, String dni_d,boolean carg) throws IOException, InvalidKeySpecException, NoSuchAlgorithmException, SQLException {

        if((nom == null) || (dni_d == null) || (cont == null))
        {
            return "Registro inválido. Complete todos los campos solicitados, por favor.";
        }
        String buscador = realizar_bus_us(nom, null, null); //Se busca solamente el nombre y el dni pues son los dos datos que no se pueden repetir

        String busca_dos = realizar_bus_us(null,null,dni_d);

        if((!buscador.contains("No se encontró ningún usuario con esos datos")) || (!busca_dos.contains("No se encontró ningún usuario con esos datos"))) {
            return "Nombre: " + buscador + "\nDNI: " + busca_dos;
        } else
        {
            String respuesta = Usuario.usbd.registrar_datos_usuario(nom,cont,dni_d,carg);
            return respuesta;
        }
    }

    public static Integer iniciar_sesion(String nom, String con, String dni_d) throws IOException, InvalidKeySpecException, NoSuchAlgorithmException, SQLException{

        String buscador = realizar_bus_us(nom, null, null); //Se busca solamente el nombre y el dni pues son los dos datos que no se pueden repetir

        String busca_dos = realizar_bus_us(null,null,dni_d);

        if((buscador.contains("El nombre ingresado está en uso")) && (busca_dos.contains("El DNI está en uso"))) { //Se espera esto porque la contraseña buscada es null; pues primero es preferible comparar que exista el usuario y después se hace el proceso de comparación de hasheos

            String permitido = String.valueOf(busca_dos.substring(18));

            try
            {
            
                Integer id_int = Integer.parseInt(permitido);
                Usuario busca = extractor(id_int);

                if(UsuarioBDD.verificador_con(con, busca.contrasena, busca.rando)) {

                    Usuario.id = id_int;
                    Logs_Intermedio.intermedio_carga_logs(Usuario.id, "El usuario " + Usuario.id.toString() + " inició sesión correctamente", "Usuario: iniciar_sesion", true);
                    return id_int;
                }

            } catch(NumberFormatException nfe)
            {
                Logs_Intermedio.intermedio_carga_logs(Usuario.id, "Ocurrió un error inesperado al intentar comparar la información del usuario", "Usuario: Inicio sesión", false);
                throw new NumberFormatException("Ocurrió un error inesperado al intentar comparar la información del ID de usuario: ");
            }

        }

        return -1;

    }

    public static String eliminar_usuario(String id_ingresado)throws IOException, SQLException {
        Integer id_usuario;
        String msj;
        try{
            id_usuario = Integer.parseInt(id_ingresado);
        }catch(NumberFormatException nfe){
            return "El ID debe ser numérico";
        }
        String verificar = realizar_bus_us(id_ingresado);
        if (verificar.contains("El usuario buscado no existe")) {
            return "El ID a eliminar no existe en los registros";
        }
        msj = Usuario.usbd.eliminar_datos_usuario(id_usuario);
        return msj;
    }
    
    public static String modificar_usr(Integer id_busca, String nom, String contra)throws IOException, InvalidKeySpecException, NoSuchAlgorithmException, SQLException {

        String msj = Usuario.usbd.buscar_usuario(id_busca);
        if(!msj.contains("El usuario buscado no existe en el sistema")){
            msj = Usuario.usbd.modificar_usuariobdd(id_busca, nom, contra);
        }
        return msj;
    }
}