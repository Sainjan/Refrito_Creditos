package main.java.Modelo;

import java.util.List;

public class Empresa extends Cliente implements FuncionCalculo {

    private static List<String> rubrosPosibles = List.of("Campo","Tecnología Aeroespacial","Tecnología Mecánica", "Tecnología electrónica","Tecnología de Sistemas","Tecnología Automotriz","Imprenta");
    private String rubro;    //Se hacen los datos privados para evitar que otros paquetes puedan hacederlos y modificarlos directamente.
    private String director; //Si se dejara que otros módulos toquen los atributos sin gestión alguna, puede ingresarse información no prevista y romper el programa.

    public Empresa(String nom, double ing, double gastosC, boolean historial, String rub, String dir)
    {
        super(nom,ing,gastosC,historial);
        this.rubro = rub;
        this.director = dir;
    }

    public String obtRubro()
    {
        return this.rubro;
    }

    public String obtDirector()
    {
        return this.director;
    }

    @Override
    public boolean evaluarRiesgo()
    {
        if(this.gastos <= (double) 0.0)
        {
            return false;
        }


    }
}