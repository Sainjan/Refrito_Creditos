package main.java.Modelo;

public enum Cargo {
    ADMINISTRADOR,
    PERSONA,
    EMPRESA; //EN la interfaz hay que hacer que los atributos extra de "EMPRESA" estén escondidos y el Listener del ComboBox los haga aparecer.
}
