/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.java.Servicio;

import java.io.IOException;
//IMPORTS DE HASHEO
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import main.java.Modelo.Usuario;
import main.java.BDD.UsuarioBDD;

public class UsuarioServicio {

    private UsuarioBDD usbd;
    private Usuario usur;

    public UsuarioServicio() {
        this.usbd = new UsuarioBDD();
    }

    public Usuario extractor(Integer id_int) throws SQLException //A revisión
    {
        Usuario buscado = this.usbd.extrae_us(id_int);

        return buscado;
    }

    public String realizar_bus_us(String id) throws SQLException{

        Integer id_fin = 0;
        try 
        {
            id_fin = Integer.parseInt(id);
        } catch (NumberFormatException nfe) 
        {
            return "Error de formato";
        }
        
        String msj = this.usbd.buscar_usuario(id_fin);

        return msj;
    }

    public String realizar_bus_us(String nom, String con) throws InvalidKeySpecException, NoSuchAlgorithmException, SQLException, IOException {
        return Usuario.usbd.buscar_usuario(nom, con);
    }

    public String registrar_usuario(String nom, String cont, boolean carg) throws IOException, InvalidKeySpecException, NoSuchAlgorithmException, SQLException {

        if((nom == null) || (cont == null))
        {
            return "Registro inválido. Complete todos los campos solicitados, por favor.";
        } else if(!nom.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]*"))
        {
            return "Registro inválido. El nombre no sigue las reglas especificadas:\n debe ser únicamente texto, sin números ni caracteres especiales";
        }
        
        String buscador = realizar_bus_us(nom, null); //Se busca solamente el nombre y el dni pues es el dato que no se puede repetir
                                                      //No es la forma más óptima, pero es necesario entrar a la BDD para saber si
                                                      //el usuario existe o no.

        if(!buscador.contains("No se encontró ningún usuario con esos datos")) {
            return buscador;
        } else
        {
            String respuesta = this.usbd.registrar_datos_usuario(nom,cont,carg);
            return respuesta;
        }
    }

    public int iniciar_sesion(String nom, String con) throws IOException, InvalidKeySpecException, NoSuchAlgorithmException, SQLException{

        String buscador = realizar_bus_us(nom, null); //Se busca solamente el nombre y el dni pues es el dato que no se puede repetir
                                                      //No es la forma más óptima, pero es necesario entrar a la BDD para saber si
                                                      //el usuario existe o no.

        if(buscador.contains("El nombre ingresado está en uso")) //Se espera esto porque la contraseña buscada es null; 
                                                                 // pues primero es preferible comparar que exista el usuario 
                                                                 // y después se hace el proceso de comparación de hasheos.
        {
            String permitido = String.valueOf(buscador.substring(18));
            try
            {
            
                Integer id_int = Integer.parseInt(permitido);
                Usuario busca = extractor(id_int);

                if(busca.verificador_con(con))
                {
                    //Usuario.id = id_int;
                    this.usur = busca;
                    Logs_Intermedio.intermedio_carga_logs(busca.obtIdUsuario(), "El usuario " + String.valueOf(busca.obtIdUsuario()) + " inició sesión correctamente", "UsuarioServicio: iniciar_sesion", true);
                    return busca.obtIdUsuario();
                }

            } catch(NumberFormatException nfe)
            {
                Logs_Intermedio.intermedio_carga_logs(1, "Ocurrió un error inesperado al intentar comparar la información del usuario", "UsuarioServicio: Inicio sesión", false);
                throw new NumberFormatException("Ocurrió un error inesperado al intentar comparar la información del ID de usuario: ");
            }

        }

        return -1;

    }

    public String eliminarUsuario() throws IOException, SQLException
    {
        String msj;
        msj = this.usbd.eliminar_datos_usuario(this.usur.obtIdUsuario());
        return msj;
    }
    
    public String modificar_usr(String nom, String contra) throws IOException, InvalidKeySpecException, NoSuchAlgorithmException, SQLException
    {
        if((nom == null) || (cont == null))
        {
            return "Modificación inválida. Complete todos los campos solicitados, por favor.";
        } else if(!nom.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]*"))
        {
            return "Modificación inválida. El nombre no sigue las reglas especificadas:\n debe ser únicamente texto, sin números ni caracteres especiales";
        }
        byte[] nuevoRando = Usuario.genera_random();
        String nuevaContra = Usuario.hasheador(contra, nuevoRando);
        String msj;
        msj = this.usbd.modificar_usuariobdd(this.usur.obtIdUsuario(), nom, nuevaContra);
        return msj;
    }
}