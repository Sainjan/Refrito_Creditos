/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package main.java;

/**
 *
 * @author sebasti-n-olmos, sebasuuu
 */

import java.time.format.DateTimeParseException;

//IMPORTS DE ARCHIVOS

import java.io.IOException;

//IMPORTS DE SQL

import java.sql.SQLException;

//IMPORTS DE INTERFAZ

import javax.swing.SwingUtilities;
import javax.swing.JOptionPane;


public class SteamML {
   
    static Usuario us;
    static UsuarioBDD usbd;
    static Logs log;
    static RedNeuronal ia;//Inicializamos la IA---------------
    static ConexionBDD con_bd; 
    static SolicitudBDD solbd;
    static Solicitud sol;
    
    public static void main(String[] args) {

        try
        {
            con_bd = new ConexionBDD();
        } catch (SQLException sqle)
        {
            System.err.println(sqle);
        } catch (IOException iox_sql)
        {
            System.err.println(iox_sql);
        }

        try 
        {
            SteamML.usbd = new UsuarioBDD();
            Usuario.usbd = SteamML.usbd;
            SteamML.us = new Usuario(usbd);
            /*ia = new RedNeuronal();//la continuamos---------------
            
            //ia.cargar_dataset();
            //ia.ejecutarEntrenamiento();//la probamos---------------
            //ia.probar_efectividad();
            /*double[] clientePrueba = {
                1.0,               // [0] Gender (Masculino)
    0.0,               // [1] Own_car (NO tiene auto - Resta)
    0.0,               // [2] Own_property (NO tiene casa propia, alquila - Resta)
    1.0,               // [3] Work_phone (Tiene teléfono laboral)
    1.0,               // [4] Phone (Tiene celular)
    1.0,               // [5] Email (Tiene email)
    0.0,               // [6] Unemployed (0.0 = NO está desempleado, LABURA - Suma estabilidad)
    1.0,         // [7] num_children (No tiene hijos - Suma porque no tiene gastos extra: 0.0)
    0.5,         // [8] num_family (Vive solo, 1 miembro -> normalizado 0.16 - Gasto bajo)
    12.0 / 100.0,      // [9] Account_length (Cuenta de 12 meses, nuevita -> 0.12)
    200000.0 / 1000000.0, // [10] Ingreso zafable ($220.000 -> normalizado 0.22)
    45.0 / 100.0,      // [11] Edad: 24 años (Es joven, para el banco es riesgo medio -> 0.24)
    10.0 / 50.0,        // [12] Years_employed (1 año y medio de antigüedad -> 0.03 - Poquito)
    1.0,               // [13] IncomeType ("Working" -> aporta confianza laboral: 1.0)
    0.8,               // [14] Education ("Secondary" / Secundario completo -> 0.4)
    0.3,               // [15] Family_status ("Single" / Soltero -> 0.3)
    0.6,               // [16] Housing_type ("Rented apartment" / Alquila -> 0.2)
    0.6
            };
            ia.gestionar_solicitud(clientePrueba);*/
            
        } catch (IOException ioe_uno) 
        {
            System.err.println(ioe_uno);
        } catch (NumberFormatException nfe) 
        {
            System.err.println(nfe);
        } catch (DateTimeParseException dtpe)
        {
            System.err.println(dtpe);
        }catch(Exception e){//Atrapamos el error de la Red Neuronal---------------
            System.err.println(e);
        }
        
        try 
        {
            SteamML.log = new Logs();
        } catch(IOException iox)
        {
            System.err.println(iox);
        }

        try
        {
            SteamML.solbd = new SolicitudBDD();
            SteamML.sol = new Solicitud(solbd);
        } catch (IOException ioe_dos)
        {
            System.err.println(ioe_dos);
        } catch (NumberFormatException nfe_dos)
        {
            System.err.println(nfe_dos);
        } catch (DateTimeParseException dtpe_dos)
        {
            System.err.println(dtpe_dos);
        } catch (IllegalArgumentException ilae)
        {
            System.out.println(ilae.getMessage());
        } catch (SQLException sqlex)
        {
            System.err.println(sqlex);
        }

        //INICIO DE PROGRAMA

        abrir_InterfazInicio();
            
    }
    
    public static void abrir_InterfazInicio()
    {
        SwingUtilities.invokeLater(new Runnable() {

        @Override
        public void run() {
            InterfazInicio ini = new InterfazInicio();
            ini.setVisible(true);
            }
        });
    }

    public static void abrir_InterfazRegistro(int llamador) {

        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                InterfazRegistro inre = new InterfazRegistro(llamador);
                inre.setVisible(true);
            }

        });
    }

    public static void abrir_InterfazInicioSesion() {

        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                InterfazInicioSesion inins = new InterfazInicioSesion();
                inins.setVisible(true);
            }

        });
    }

    static void abrir_InterfazCliente() {
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                InterfazCliente incli = new InterfazCliente();
                incli.setVisible(true);
            }

        });
    }

    static void abrir_InterfazAdmin() {
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                InterfazAdmin inad = new InterfazAdmin();
                inad.setVisible(true);
            }

        });
    }

    static void abrir_InterfazModificarUsuario(boolean indicador) {
       SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                InterfazModificarUsuario inmous = new InterfazModificarUsuario(indicador);
                inmous.setVisible(true);
            }

        });
    }
     
    static void abrir_EliminarUser(boolean origen) {
       SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                EliminarUser elus = new EliminarUser(origen);
                elus.setVisible(true);
            }

        });
    }

    static void abrir_InterfazCuestionario() {
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {

                InterfazCuestionario incu = new InterfazCuestionario();
                incu.setVisible(true);

            }
        });
    }
    
    static void abrir_InterfazRedNeuronal() {
             SwingUtilities.invokeLater(() -> {
            InterfazRedNeuronalAdmin inrn = new InterfazRedNeuronalAdmin();
            inrn.setVisible(true);
        });
     }
    
    static void abrir_InterfazInfoSolicitud(Integer id) {
       SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                try
                {
                    InterfazInfoSolicitud ininfso = new InterfazInfoSolicitud(id, SteamML.us);
                    ininfso.setVisible(true);
                } catch (IllegalArgumentException ilae)
                {
                    JOptionPane.showMessageDialog(null, ilae.getMessage()); //Hago getMessage porque queda feo mostrar como "java.lang.error" al usuario.
                                                                            //Este es un error probable al ser generado intencionalmente como advertencia
                } catch (SQLException sqleee)
                {
                    JOptionPane.showMessageDialog(null, sqleee);
                }
            }

        });
    }

    static void abrir_InterfazListadoLogs() {
        SwingUtilities.invokeLater(() -> {
            InterfazListadoLogs inlisl = new InterfazListadoLogs();
            inlisl.setVisible(true);
        });
    }

    static void abrir_InterfazSolicitudesUsuario() {
        SwingUtilities.invokeLater(() -> {
            InterfazSolicitudesUsuario insous = new InterfazSolicitudesUsuario();
            insous.setVisible(true);
        });
    }

    static void abrir_InterfazVerificaContrasena(int llamador, int direccionador)
    {
        SwingUtilities.invokeLater(() -> {
            InterfazVerificaContrasena invc = new InterfazVerificaContrasena(llamador, direccionador);
            invc.setVisible(true);
        });
    }
}