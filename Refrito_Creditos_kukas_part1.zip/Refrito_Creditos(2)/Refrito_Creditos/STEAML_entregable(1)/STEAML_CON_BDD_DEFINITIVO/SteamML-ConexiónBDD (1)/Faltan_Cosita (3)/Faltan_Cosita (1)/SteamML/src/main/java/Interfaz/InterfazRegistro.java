/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.java.Interfaz;

import java.awt.Color;
import java.awt.event.*;
import java.awt.Event;
import java.security.spec.InvalidKeySpecException;
import java.security.NoSuchAlgorithmException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.io.IOException;

import java.sql.SQLException;

public class InterfazRegistro extends JFrame implements ActionListener {
   JLabel  lb_nombre, miLabel, lb_contrasena, lb_dni;
   JTextField txt_nombre; 
   JFormattedTextField txt_dni;
   JPasswordField txt_contrasena;
   JButton btn_ingresar; 
   JComboBox<String> asignador_rol;

    boolean validador_cierre = true;
    int valor_pasaje;

    public InterfazRegistro(int pasador) {

        setBounds(400, 200, 500, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosed(WindowEvent wev) {

                if((validador_cierre) && (pasador == 1)) 
                {
                    SteamML.abrir_InterfazInicio();
                } else if ((validador_cierre) && (pasador == 0))
                {
                    SteamML.abrir_InterfazInicioSesion();
                } else if((validador_cierre) && (pasador == 2))
                {
                    SteamML.abrir_InterfazAdmin();
                }

            } 

        });

        ImageIcon iconOriginal = new ImageIcon("/home/fran/Escritorio/Captura desde 2026-06-08 13-39-41.png");
        java.awt.Image imgEscalada = iconOriginal.getImage().getScaledInstance(80, 80, java.awt.Image.SCALE_SMOOTH);
        miLabel = new JLabel(new ImageIcon(imgEscalada));
        miLabel.setBounds(210, 5, 80, 80); 

        lb_nombre = new JLabel("Ingrese su nombre de usuario:");
        lb_nombre.setBounds(50,30,300,20);
        lb_nombre.setForeground(new Color(25, 25, 112));

        txt_nombre = new JTextField("Pepe");
        txt_nombre.setForeground(Color.LIGHT_GRAY);
        txt_nombre.setBounds(245,30,150,20);
        txt_nombre.addFocusListener(new FocusListener() {
            
            @Override
            public void focusGained(FocusEvent fe)
            {
                if(txt_nombre.getText() != "Pepe")
                {
                    txt_nombre.setText("");
                    txt_nombre.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent fev)
            {
                if(txt_nombre.getText().isEmpty())
                {
                    txt_nombre.setText("Pepe");
                    txt_nombre.setForeground(Color.LIGHT_GRAY);
                }
            }
        });

        lb_dni = new JLabel("Ingrese su DNI:");
        lb_dni.setBounds(50, 70, 100, 20);
        lb_dni.setForeground(new Color(25, 25, 112));
        /*txt_dni = new JTextField(8);
        txt_dni.setBounds(300, 156, 150, 30);*/

        lb_contrasena = new JLabel("Ingrese su contraseña:");
        lb_contrasena.setBounds(50,110,300,20);
        lb_contrasena.setForeground(new Color(25, 25, 112));

        txt_contrasena = new JPasswordField("contrasena123");
        txt_contrasena.setForeground(Color.LIGHT_GRAY);
        //txt_contrasena.setEchoChar('°');
        txt_contrasena.setBounds(245,110,150,20);
        txt_contrasena.addFocusListener(new FocusListener() {
            
            @Override
            public void focusGained(FocusEvent fe)
            {
                if(!txt_contrasena.getPassword().toString().equals("contrasena123"))
                {
                    txt_contrasena.setText("");
                    txt_contrasena.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent fev)
            {
                if(txt_contrasena.getPassword().toString().isEmpty())
                {
                    txt_contrasena.setText("contrasena123");
                    txt_contrasena.setForeground(Color.LIGHT_GRAY);
                }
            }
        });

        JLabel as_rol_lbl = new JLabel("Rol:");
        as_rol_lbl.setBounds(50,150,50,20);
        as_rol_lbl.setForeground(new Color(25,25,112));

        asignador_rol = new JComboBox<>(new String[]{"Cliente","Administrador"});
        asignador_rol.setBounds(245,150,150,20);

        btn_ingresar = new JButton("Registrarse");
        btn_ingresar.setBounds(150,210,150,40);
        btn_ingresar.setForeground(Color.WHITE);
        btn_ingresar.setBackground(new Color(0, 100, 60));
        btn_ingresar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent me) {
                btn_ingresar.setBackground(new Color(25, 25, 112));
            }
            @Override
            public void mouseExited(MouseEvent mev) {
                btn_ingresar.setBackground(new Color(0, 100, 60));
            }
        });
        btn_ingresar.addActionListener(this);

        add(miLabel);
        add(lb_nombre);
        add(txt_nombre);
        add(lb_contrasena);
        add(txt_contrasena);
        add(lb_dni);
        if(Usuario.id.equals(1))
        {
            add(as_rol_lbl);
            add(asignador_rol);
        }
        add(btn_ingresar);

        try
        {
            MaskFormatter mas_u = new MaskFormatter("########");
            mas_u.setPlaceholderCharacter('_');

            txt_dni = new JFormattedTextField(mas_u);
            txt_dni.setColumns(8);
            txt_dni.setBounds(245,70,150,20);

            add(txt_dni);
        } catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e);
        }
    }
        public void actionPerformed(ActionEvent e) {
            String nom_obt = txt_nombre.getText();
            char[] con_obt = txt_contrasena.getPassword();
            String con_final = String.valueOf(con_obt);
            String dni_obt = txt_dni.getText();
            //String[] dni_casi = dni_obt.split(".");
            //String dni_final = dni_casi[0] + dni_casi[1] + dni_casi[2];

            boolean cargo = false;
            if(Usuario.id.equals(1))
            {
                int cargo_elegido = asignador_rol.getSelectedIndex();

                if(cargo_elegido == 1)
                {
                    cargo = true;
                }
            }

            try {

                String resultado = Usuario.registrar_usuario(nom_obt, con_final, dni_obt, cargo);

                JOptionPane.showMessageDialog(this, resultado);

            } catch(InvalidKeySpecException ikse) {
                JOptionPane.showMessageDialog(this, ikse);
            } catch (NumberFormatException nfe) {
                JOptionPane.showMessageDialog(this, nfe);
            } catch(IOException ioe) {
                JOptionPane.showMessageDialog(this, ioe);
            } catch (NoSuchAlgorithmException nsue) {
                JOptionPane.showMessageDialog(this, nsue);
            } catch (SQLException sqle_r)
            {
                JOptionPane.showMessageDialog(this, sqle_r);
            }
        }
    }