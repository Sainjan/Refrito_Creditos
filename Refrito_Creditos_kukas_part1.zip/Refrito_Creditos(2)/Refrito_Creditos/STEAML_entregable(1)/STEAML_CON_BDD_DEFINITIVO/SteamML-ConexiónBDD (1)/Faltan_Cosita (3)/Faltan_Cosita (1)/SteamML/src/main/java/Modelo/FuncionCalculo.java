package main.java.Modelo;

public interface FuncionCalculo {

    public boolean evaluarRiesgo();
}