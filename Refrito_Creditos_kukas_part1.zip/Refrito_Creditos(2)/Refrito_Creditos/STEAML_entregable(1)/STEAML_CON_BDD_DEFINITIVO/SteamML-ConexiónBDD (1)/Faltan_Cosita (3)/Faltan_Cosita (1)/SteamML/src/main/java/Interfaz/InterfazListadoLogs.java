/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.java.Interfaz;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseAdapter;
import java.awt.event.FocusListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JFormattedTextField;
import javax.swing.text.MaskFormatter;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;

import java.util.ArrayList;
import java.text.ParseException;

import java.sql.SQLException;

/**
 *
 * @author fran
 */
public class InterfazListadoLogs extends JFrame implements ActionListener {
    
    boolean validador_cierre = true;
    JComboBox<String> cbBuscar, cbEstado;
    JFormattedTextField txtFecha;
    JTextField proceso_txt;
    JLabel proceso_lbl;
    JButton btnFiltrar, btnNoFiltrar;
    DefaultTableModel modelo;
    JTable tabla;

    public InterfazListadoLogs() {

        setTitle("Listado de Logs");
        setBounds(300, 150, 780, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    
        setLayout(new BorderLayout()); 

        // Panel superior para los controles de filtrado
        JPanel panelSuperior = new JPanel();
        panelSuperior.setLayout(null);
        panelSuperior.setPreferredSize(new java.awt.Dimension(780, 80));

        // Componentes de búsqueda y filtros
        JLabel lblBuscar = new JLabel("Buscar:");
        lblBuscar.setBounds(20, 25, 50, 25);
        panelSuperior.add(lblBuscar);

        cbBuscar = new JComboBox<>(new String[]{"Antes de:", "Después de:"});
        cbBuscar.setBounds(70, 25, 100, 25);
        panelSuperior.add(cbBuscar);

        proceso_lbl = new JLabel("Proceso:");
        proceso_lbl.setBounds(185,60,45,20);
        panelSuperior.add(proceso_lbl);

        proceso_txt = new JTextField("[SQL] Buscar_Usuarios()");
        proceso_txt.setForeground(Color.LIGHT_GRAY);
        proceso_txt.setBounds(230,60,200,20);
        proceso_txt.addFocusListener(new FocusAdapter() {

            @Override
            public void focusGained(FocusEvent fe)
            {
                if(proceso_txt.getText() != "[SQL] Buscar_Usuarios()")
                {
                    proceso_txt.setText("");
                    proceso_txt.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent fev)
            {
                if(proceso_txt.getText().isEmpty())
                {
                    proceso_txt.setText("[SQL] Buscar_Usuarios()");
                    proceso_txt.setForeground(Color.LIGHT_GRAY);
                }
            }
        });
        panelSuperior.add(proceso_txt);

        JLabel lblFecha = new JLabel("Fecha:");
        lblFecha.setBounds(185, 25, 45, 25);
        panelSuperior.add(lblFecha);

        JLabel lblEstado = new JLabel("Estado:");
        lblEstado.setBounds(355, 25, 50, 25);
        panelSuperior.add(lblEstado);

        cbEstado = new JComboBox<>(new String[]{"Aprobado", "Rechazado"});
        cbEstado.setBounds(410, 25, 100, 25);
        panelSuperior.add(cbEstado);

        btnNoFiltrar = new JButton("No Filtrar");
        btnNoFiltrar.setForeground(Color.WHITE);
        btnNoFiltrar.setBackground(new Color(0,100,60));
        btnNoFiltrar.setBounds(630, 15, 110, 25);
        btnNoFiltrar.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseEntered(MouseEvent moen)
            {
                btnNoFiltrar.setBackground(new Color(25,25,112));
                btnNoFiltrar.setForeground(Color.WHITE.darker());
            }

            @Override
            public void mouseExited(MouseEvent moex)
            {
                btnNoFiltrar.setBackground(new Color(0,100,60));
                btnNoFiltrar.setForeground(Color.WHITE);
            }

        });
        btnNoFiltrar.addActionListener(this);
        panelSuperior.add(btnNoFiltrar);

        btnFiltrar = new JButton("Filtrar");
        btnFiltrar.setForeground(Color.WHITE);
        btnFiltrar.setBackground(new Color(0,100,60));
        btnFiltrar.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseExited(MouseEvent moev)
            {
                btnFiltrar.setBackground(new Color(0,100,60));
                btnFiltrar.setForeground(Color.WHITE);
            }

            @Override
            public void mouseEntered(MouseEvent moen)
            {
                btnFiltrar.setBackground(new Color(25,25,112));
                btnFiltrar.setForeground(Color.WHITE.darker());
            }

        });
        btnFiltrar.setBounds(630, 45, 110, 25);
        btnFiltrar.addActionListener(this);
        panelSuperior.add(btnFiltrar);

        try
        {
            MaskFormatter mascara_fecha = new MaskFormatter("####-##-##");
            mascara_fecha.setPlaceholderCharacter('0');

            txtFecha = new JFormattedTextField(mascara_fecha);
            txtFecha.setColumns(10);
            txtFecha.setBounds(230, 25, 110, 25);
            panelSuperior.add(txtFecha);
        } catch (ParseException pe)
        {
            JOptionPane.showMessageDialog(this,pe.getMessage());
        }

        add(panelSuperior, BorderLayout.NORTH);

        // Tabla y ScrollPane en el centro
        String[] columnas = {"Id", "Fecha", "Mensaje", "Proceso", "Estado", "Id de usuario responsable"};
        modelo = new DefaultTableModel(columnas, 0);
        tabla = new JTable(modelo);
        JScrollPane scrollPane = new JScrollPane(tabla);

        try {
            ArrayList<Logs_Intermedio> busqueda = Logs_Intermedio.listador_log("0000-00-00", null, false, false);

            cargar_tabla(busqueda);
            
        } catch (IllegalArgumentException ilae) 
        {
            JOptionPane.showMessageDialog(this, ilae.getMessage());
        } catch (SQLException sqlex_do)
        {
            JOptionPane.showMessageDialog(this, sqlex_do);
        } catch (Exception ex) 
        {
            JOptionPane.showMessageDialog(this, ex);
        }

        add(scrollPane, BorderLayout.CENTER);
    }

    private void cargar_tabla(ArrayList<Logs_Intermedio> registros)
    {
        for(Logs_Intermedio item : registros)
        {
            String str_estado = "Rechazado";
            if(item.estado)
            {
                str_estado = "Aprobado";
            }
            modelo.addRow(new Object[]{item.id_log, item.fecha, item.mensaje, item.proceso, str_estado, item.id_resp});
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        if (e.getSource() == btnFiltrar) 
        {
            boolean elec_men_mas; //"elec" refiere a electo o elegido 
            int posicion_combo_men_mas = cbBuscar.getSelectedIndex();

            if(posicion_combo_men_mas == 0)
            {
                elec_men_mas = false;
            } else
            {
                elec_men_mas = true;
            }

            boolean elec_estado;
            int posicion_combo_estado = cbEstado.getSelectedIndex();

            if(posicion_combo_estado == 0)
            {
                elec_estado = true;
            } else
            {
                elec_estado = false;
            }

            String fecha_ingresada = txtFecha.getText();
            if(fecha_ingresada.length() < 10)
            {
                fecha_ingresada = "0000-00-00";
            }
            String proceso_ingresado;
            if(proceso_txt.getBackground().equals(Color.BLACK))
            {
                proceso_ingresado = proceso_txt.getText();
            } else
            {
                proceso_ingresado = null;
            }

            try
            {

                ArrayList<Logs_Intermedio> registro_intermedio = Logs_Intermedio.listador_log(fecha_ingresada,proceso_ingresado,elec_estado,elec_men_mas);

                cargar_tabla(registro_intermedio);

            } catch (SQLException sqle_e)
            {
                JOptionPane.showMessageDialog(this, sqle_e);
            }
            // Lógica de filtrado
        } else if (e.getSource() == btnNoFiltrar)
        {
            try
            {
                ArrayList<Logs_Intermedio> registro_intermedio = Logs_Intermedio.listador_log("0000-00-00",null,false,false);

                cargar_tabla(registro_intermedio);
            } catch (SQLException sqlex_u)
            {
                JOptionPane.showMessageDialog(this, sqlex_u);
            }
        }
    }
}