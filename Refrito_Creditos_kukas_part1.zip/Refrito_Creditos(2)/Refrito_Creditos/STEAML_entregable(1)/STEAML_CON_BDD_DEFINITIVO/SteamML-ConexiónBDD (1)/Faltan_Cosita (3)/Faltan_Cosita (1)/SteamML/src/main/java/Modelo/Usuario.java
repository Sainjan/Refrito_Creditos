package main.java.Modelo;

import java.time.LocalDate;

public class Usuario {
    
    private int idUsuario, numeroIntentos;
    private String nombreUsuario, contrasena, salt;
    private Cargo rol;
    private LocalDate ultimoIntento;
    private Empresa emp;
    private Persona per;

    public Usuario(int idUs, String nomUs, String con, String rando, boolean cargo, int intentos, LocalDate ultInt) //Constructor para usuarios existentes.
    {
        this.idUsuario = idUs;
        this.nombreUsuario = nomUs;
        this.contrasena = con;
        this.salt = rando; //El salt pertenece a un formato de texto que se implementa a la hora de encriptar un texto.
        this.rol = cargo ? Cargo.EMPRESA : Cargo.PERSONA; //Se hace como "if acotado" para simplificar líneas, aunque no me convence.
        this.numeroIntentos = intentos;
        this.ultimoIntento = ultInt;
    }

    public Usuario(String nomUs, String con, String rando) //Constructor únicamente usado para el usuario "idUsuario = 1" en la base de datos. Si su ID es distinto, usa el otro constructor.
    {
        this.idUsuario = 1; //Si llamó a este constructor, el ID es obligatoriamente <1>
        this.nombreUsuario = nomUs;
        this.contrasena = con;
        this.salt = rando;
        this.rol = Cargo.ADMINISTRADOR; //Única forma legal de obtener acceso de "Administrador". Es necesario implementar más cosas que validen que está intrínsecamente conectado con el "idUsuario = 1".
        this.numeroIntentos = 999;
        this.ultimoIntento = null;
    }

    public int obtIdUsuario()
    {
        return this.idUsuario;
    }

    public String obtNomUs()
    {
        return this.nombreUsuario;
    }

    public Cargo obtRol()
    {
        return this.rol;
    }

    public int obtNumIntentos()
    {
        return this.numeroIntentos;
    }

    public LocalDate obtUltIntento()
    {
        return this.ultimoIntento;
    }

    public Empresa obtEmpresa()
    {
        return this.emp;
    }

    public Persona obtPersona()
    {
        return this.per;
    }
}
