package main.java.Modelo;

public enum Cargo {
    ADMINISTRADOR,
    PERSONA,
    EMPRESA;
}
