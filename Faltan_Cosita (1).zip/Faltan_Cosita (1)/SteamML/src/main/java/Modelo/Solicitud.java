package main.java.Modelo;

import java.time.LocalDate;
import java.sql.SQLException;

import main.java.Modelo.Usuario;

public class Solicitud{

    Integer idSolicitud; 
    double ingresos, gastos, montoMaximo;
    LocalDate fecha; 
    String estado;
    Usuario solicitante;

    public Solicitud(Integer idSolicitud, double ingresos, double gastos, String estado, LocalDate fecha, Usuario solicitante) throws SQLException {
        this.idSolicitud = idSolicitud;
        this.ingresos = ingresos;
        this.gastos = gastos;

        if (estado.equalsIgnoreCase("Pendiente") || estado.equalsIgnoreCase("Rechazado") || estado.equalsIgnoreCase("Confirmado")) {
            this.estado = estado;
        } else {
            this.estado = "Pendiente";
        }
 
        if (fecha != null) {
            this.fecha = fecha;
        } else {
            this.fecha = LocalDate.now(); 
        }

        this.solicitante = solicitante;
    }

    public double obtIngresos(){
        return this.ingresos;
    }

    public double obtGastos(){
        return this.gastos;
    }

    public String obtEstado(){
        return this.estado;
    }

    public LocalDate obtFecha(){
        return this.fecha;
    }

    public void setEstado(String nuevoEstado){
        this.estado = nuevoEstado;
    }

    public boolean evaluarRiesgo() {
        return this.solicitante.evaluaRiesgo();
    }

    public double getMontoMaximo() {
        return ReglaMaestra.calcularMontoRMC3(this.ingresos, this.gastos);
    }
}
