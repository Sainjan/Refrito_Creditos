package main.java.Modelo;

import java.time.LocalDate;
import java.sql.SQLException;

public class Solicitud{

    Integer idSolicitud; 
    String nombre;
    double ingresos, gastos, montoMaximo;
    LocalDate fecha; 
    String estado;

    public Solicitud(Integer idSolicitud, double ingresos, double gastos, String estado, LocalDate fecha) throws SQLException {
        this.idSolicitud = idSolicitud;
        this.ingresos = ingresos;
        this.gastos = gastos;

        if (estado.equalsIgnoreCase("Pendiente") || estado.equalsIgnoreCase("Rechazado") || estado.equalsIgnoreCase("Confirmado")) {
            this.estado = estado;
        } else {
            this.estado = "Pendiente";
        }
 
        if (fecha != null) {
            this.fecha = fecha;
        } else {
            this.fecha = LocalDate.now(); 
        }
    }

    public double obtIngresos(){
        return this.ingresos;
    }

    public double obtGastos(){
        return this.gastos;
    }

    public String obtEstado(){
        return this.estado;
    }

    public LocalDate obtFecha(){
        return this.fecha;
    }

    public String setEstado(String nuevoEStado){
        this.estado = nuevoEstado;
    }
}
